import { pgTable, text, serial, integer, numeric, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Currency table for storing forex and crypto currencies
export const currencies = pgTable("currencies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  symbol: text("symbol").notNull().unique(),
  priceUsd: numeric("price_usd", { precision: 20, scale: 8 }).notNull(),
  percentChange24h: numeric("percent_change_24h", { precision: 10, scale: 2 }),
  percentChange7d: numeric("percent_change_7d", { precision: 10, scale: 2 }),
  marketCapUsd: numeric("market_cap_usd", { precision: 20, scale: 2 }),
  volumeUsd24h: numeric("volume_usd_24h", { precision: 20, scale: 2 }),
  type: text("type").notNull(), // "forex" or "crypto"
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Exchanges table for cryptocurrency exchanges
export const exchanges = pgTable("exchanges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  logo: text("logo"),
  url: text("url").notNull(),
  country: text("country"),
  regulated: boolean("regulated").default(false),
  volume24h: numeric("volume_24h", { precision: 20, scale: 2 }),
  markets: integer("markets"),
  trustScore: numeric("trust_score", { precision: 3, scale: 1 }),
  fiatSupport: text("fiat_support"),
  tradingFees: text("trading_fees"),
  btcPrice: numeric("btc_price", { precision: 20, scale: 2 }),
  ethPrice: numeric("eth_price", { precision: 20, scale: 2 }),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Conversion history for users
export const conversionHistory = pgTable("conversion_history", {
  id: serial("id").primaryKey(),
  fromCurrency: text("from_currency").notNull(),
  toCurrency: text("to_currency").notNull(),
  fromAmount: numeric("from_amount", { precision: 20, scale: 8 }).notNull(),
  toAmount: numeric("to_amount", { precision: 20, scale: 8 }).notNull(),
  rate: numeric("rate", { precision: 20, scale: 8 }).notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  ipAddress: text("ip_address"),
});

// Insert schemas for validation
export const insertCurrencySchema = createInsertSchema(currencies).omit({
  id: true,
  updatedAt: true,
});

export const insertExchangeSchema = createInsertSchema(exchanges).omit({
  id: true,
  updatedAt: true,
});

export const insertConversionHistorySchema = createInsertSchema(conversionHistory).omit({
  id: true,
  timestamp: true,
});

// Types
export type Currency = typeof currencies.$inferSelect;
export type InsertCurrency = z.infer<typeof insertCurrencySchema>;

export type Exchange = typeof exchanges.$inferSelect;
export type InsertExchange = z.infer<typeof insertExchangeSchema>;

export type ConversionHistory = typeof conversionHistory.$inferSelect;
export type InsertConversionHistory = z.infer<typeof insertConversionHistorySchema>;
