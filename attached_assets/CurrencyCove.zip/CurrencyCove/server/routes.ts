import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import axios from "axios";
import { z } from "zod";
import { insertConversionHistorySchema, insertCurrencySchema, insertExchangeSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for currency data
  app.get("/api/forex", getForexCurrencies);
  app.get("/api/crypto", getCryptoCurrencies);
  app.get("/api/convert", convertCurrency);
  app.get("/api/chart/:symbol/:timeRange", getChartData);
  app.get("/api/exchanges", getExchanges);
  app.get("/api/currencies", getAllCurrencies);
  app.get("/api/conversion-history", getConversionHistory);
  
  // Database seed/sync routes
  app.post("/api/sync-forex", syncForexCurrencies);
  app.post("/api/sync-crypto", syncCryptoCurrencies);
  app.post("/api/sync-exchanges", syncExchanges);

  const httpServer = createServer(app);
  return httpServer;
}

// API Route Handlers
async function getForexCurrencies(req: Request, res: Response) {
  try {
    // First check if we have forex currencies in the database
    const dbCurrencies = await storage.getCurrencies("forex");
    
    if (dbCurrencies.length > 0) {
      // Return currencies from database if available
      return res.json(dbCurrencies);
    }
    
    // If no currencies in database, fetch from API
    const EXCHANGE_RATE_API_KEY = process.env.VITE_EXCHANGE_RATE_API_KEY;
    const apiEndpoint = EXCHANGE_RATE_API_KEY 
      ? `https://v6.exchangerate-api.com/v6/${EXCHANGE_RATE_API_KEY}/latest/USD`
      : "https://v6.exchangerate-api.com/v6/demo/latest/USD";
    
    const response = await axios.get(apiEndpoint);
    if (response.data.result !== "success") {
      throw new Error("Failed to fetch forex rates");
    }
    
    // Transform response to our format
    const forexCurrencies = Object.entries(response.data.conversion_rates)
      .filter(([code]) => code !== "USD") // Remove USD as it's the base
      .map(([code, rate], index) => {
        const percentChange24h = Math.random() * 2 - 1; // Random value between -1 and 1
        const percentChange7d = Math.random() * 4 - 2; // Random value between -2 and 2
        
        return {
          name: getCurrencyName(code),
          symbol: code,
          priceUsd: 1 / Number(rate), // Invert to get value in USD
          percentChange24h,
          percentChange7d,
          marketCapUsd: null,
          volumeUsd24h: null,
          type: "forex" as const,
        };
      })
      .sort((a, b) => b.priceUsd - a.priceUsd) // Sort by price
      .slice(0, 10); // Get top 10
    
    // Return the forex currencies
    res.json(forexCurrencies);
  } catch (error) {
    console.error("Error fetching forex data:", error);
    res.status(500).json({ message: "Failed to fetch forex data" });
  }
}

async function getCryptoCurrencies(req: Request, res: Response) {
  try {
    // First check if we have crypto currencies in the database
    const dbCurrencies = await storage.getCurrencies("crypto");
    
    if (dbCurrencies.length > 0) {
      // Return currencies from database if available
      return res.json(dbCurrencies);
    }
    
    // If no currencies in database, fetch from API
    const COIN_GECKO_API_KEY = process.env.VITE_COIN_GECKO_API_KEY;
    const headers = COIN_GECKO_API_KEY ? { 'x-cg-pro-api-key': COIN_GECKO_API_KEY } : {};
    const baseUrl = COIN_GECKO_API_KEY ? 'https://pro-api.coingecko.com/api/v3' : 'https://api.coingecko.com/api/v3';
    
    const apiUrl = `${baseUrl}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false&price_change_percentage=24h,7d`;
    
    const response = await axios.get(apiUrl, { headers });
    
    const cryptoCurrencies = response.data.map((coin: any) => ({
      name: coin.name,
      symbol: coin.symbol.toUpperCase(),
      priceUsd: coin.current_price,
      percentChange24h: coin.price_change_percentage_24h || 0,
      percentChange7d: coin.price_change_percentage_7d_in_currency || 0,
      marketCapUsd: coin.market_cap,
      volumeUsd24h: coin.total_volume,
      type: "crypto" as const,
    }));
    
    // Return the crypto currencies
    res.json(cryptoCurrencies);
  } catch (error) {
    console.error("Error fetching crypto data:", error);
    res.status(500).json({ message: "Failed to fetch crypto data" });
  }
}

async function getAllCurrencies(req: Request, res: Response) {
  try {
    const type = req.query.type as string | undefined;
    const currencies = await storage.getCurrencies(type);
    res.json(currencies);
  } catch (error) {
    console.error("Error fetching all currencies:", error);
    res.status(500).json({ message: "Failed to fetch currencies" });
  }
}

async function convertCurrency(req: Request, res: Response) {
  try {
    const { from, to, amount } = req.query;
    
    if (!from || !to || !amount) {
      return res.status(400).json({ message: "Missing required parameters" });
    }
    
    const fromCurrency = from as string;
    const toCurrency = to as string;
    const fromAmount = parseFloat(amount as string);
    
    if (isNaN(fromAmount)) {
      return res.status(400).json({ message: "Amount must be a number" });
    }
    
    // Try to use the real API if we have keys
    try {
      const EXCHANGE_RATE_API_KEY = process.env.VITE_EXCHANGE_RATE_API_KEY;
      if (EXCHANGE_RATE_API_KEY) {
        const apiUrl = `https://v6.exchangerate-api.com/v6/${EXCHANGE_RATE_API_KEY}/pair/${fromCurrency}/${toCurrency}/${fromAmount}`;
        const response = await axios.get(apiUrl);
        
        if (response.data.result === "success") {
          // Save conversion to database
          try {
            const conversionData = {
              fromCurrency,
              toCurrency,
              fromAmount: fromAmount.toString(),
              toAmount: response.data.conversion_result.toString(),
              rate: response.data.conversion_rate.toString(),
              ipAddress: req.ip || null
            };
            
            const savedConversion = await storage.saveConversionHistory(conversionData);
            
            return res.json({
              convertedAmount: response.data.conversion_result,
              rate: response.data.conversion_rate,
              timestamp: response.data.time_last_update_unix,
              conversionId: savedConversion.id
            });
          } catch (dbError) {
            console.error("Database error saving conversion:", dbError);
          }
        }
      }
    } catch (apiError) {
      console.error("API error during conversion:", apiError);
    }
    
    // Fallback to local conversion if API fails
    const rate = getExchangeRate(fromCurrency, toCurrency);
    const convertedAmount = fromAmount * rate;
    
    // Save conversion to database
    try {
      const conversionData = {
        fromCurrency,
        toCurrency,
        fromAmount: fromAmount.toString(),
        toAmount: convertedAmount.toString(),
        rate: rate.toString(),
        ipAddress: req.ip || null
      };
      
      const savedConversion = await storage.saveConversionHistory(conversionData);
      
      res.json({
        convertedAmount,
        rate,
        timestamp: Math.floor(Date.now() / 1000),
        conversionId: savedConversion.id
      });
    } catch (dbError) {
      console.error("Database error saving conversion with fallback:", dbError);
      
      // Still return the conversion even if we couldn't save it
      res.json({
        convertedAmount,
        rate,
        timestamp: Math.floor(Date.now() / 1000)
      });
    }
  } catch (error) {
    console.error("Error converting currency:", error);
    res.status(500).json({ message: "Failed to convert currency" });
  }
}

async function getChartData(req: Request, res: Response) {
  try {
    const { symbol, timeRange } = req.params;
    
    // Try to get real data from CoinGecko if it's a cryptocurrency
    try {
      const COIN_GECKO_API_KEY = process.env.VITE_COIN_GECKO_API_KEY;
      if (COIN_GECKO_API_KEY && isCrypto(symbol)) {
        const headers = { 'x-cg-pro-api-key': COIN_GECKO_API_KEY };
        const coinId = getCoinGeckoId(symbol);
        
        if (coinId) {
          // Define the period based on the time range
          let days = '1';
          switch (timeRange) {
            case "1D": days = '1'; break;
            case "1W": days = '7'; break;
            case "1M": days = '30'; break;
            case "3M": days = '90'; break;
            case "1Y": days = '365'; break;
            case "All": days = 'max'; break;
          }
          
          // Get market chart data from CoinGecko
          const baseUrl = 'https://pro-api.coingecko.com/api/v3';
          const apiUrl = `${baseUrl}/coins/${coinId}/market_chart?vs_currency=usd&days=${days}`;
          
          const response = await axios.get(apiUrl, { headers });
          
          if (response.data && response.data.prices && Array.isArray(response.data.prices)) {
            // Transform the data to our expected format
            const data = response.data.prices.map((item: [number, number]) => ({
              time: new Date(item[0]).toISOString(),
              price: item[1],
            }));
            
            return res.json(data);
          }
        }
      }
    } catch (apiError) {
      console.error("API error fetching chart data:", apiError);
    }
    
    // Fallback to generated data
    const now = new Date();
    const data = [];
    
    let points = 24;
    let interval = 60 * 60 * 1000; // 1 hour in milliseconds
    
    switch (timeRange) {
      case "1W": points = 7; interval = 24 * 60 * 60 * 1000; break;
      case "1M": points = 30; interval = 24 * 60 * 60 * 1000; break;
      case "3M": points = 90; interval = 24 * 60 * 60 * 1000; break;
      case "1Y": points = 12; interval = 30 * 24 * 60 * 60 * 1000; break;
      case "All": points = 60; interval = 30 * 24 * 60 * 60 * 1000; break;
    }
    
    // Base price on currency type
    let basePrice = 1.0;
    
    if (symbol === "BTC") basePrice = 28000;
    else if (symbol === "ETH") basePrice = 1800;
    else if (symbol === "BNB") basePrice = 250;
    else if (symbol === "SOL") basePrice = 92;
    else if (symbol === "XRP") basePrice = 0.55;
    else if (symbol === "ADA") basePrice = 0.48;
    else if (symbol === "DOGE") basePrice = 0.13;
    
    // For forex, use more realistic values
    else if (symbol === "EUR") basePrice = 1.09;
    else if (symbol === "GBP") basePrice = 1.27;
    else if (symbol === "JPY") basePrice = 0.0066;
    else if (symbol === "CAD") basePrice = 0.74;
    else if (symbol === "AUD") basePrice = 0.67;
    else if (symbol === "CHF") basePrice = 1.13;
    
    let lastPrice = basePrice;
    const volatility = isCrypto(symbol) ? 0.025 : 0.002; // Higher volatility for crypto
    
    for (let i = points; i >= 0; i--) {
      const time = new Date(now.getTime() - i * interval);
      // Create realistic movements
      const change = (Math.random() * 2 - 1) * volatility;
      lastPrice = lastPrice * (1 + change);
      
      data.push({
        time: time.toISOString(),
        price: lastPrice,
      });
    }
    
    res.json(data);
  } catch (error) {
    console.error("Error fetching chart data:", error);
    res.status(500).json({ message: "Failed to fetch chart data" });
  }
}

async function getExchanges(req: Request, res: Response) {
  try {
    // First check if we have exchanges in the database
    const dbExchanges = await storage.getExchanges();
    
    if (dbExchanges.length > 0) {
      // Return exchanges from database if available
      return res.json(dbExchanges);
    }
    
    // If no exchanges in database, return our default exchanges
    const exchanges = [
      {
        name: "Binance",
        logo: "binance.png",
        url: "https://www.binance.com",
        country: "Global",
        regulated: true,
        volume24h: "13200000000",
        markets: 350,
        trustScore: "4.8",
        fiatSupport: "USD, EUR, GBP, AUD",
        tradingFees: "0.1% - 0.02%",
        btcPrice: "24310.88",
        ethPrice: "1843.66",
      },
      {
        name: "Coinbase",
        logo: "coinbase.png",
        url: "https://www.coinbase.com",
        country: "United States",
        regulated: true,
        volume24h: "3800000000",
        markets: 150,
        trustScore: "4.5",
        fiatSupport: "USD, EUR, GBP",
        tradingFees: "0.6% - 0.1%",
        btcPrice: "24328.40",
        ethPrice: "1845.22",
      },
      {
        name: "Kraken",
        logo: "kraken.png",
        url: "https://www.kraken.com",
        country: "United States",
        regulated: true,
        volume24h: "2100000000",
        markets: 130,
        trustScore: "4.7",
        fiatSupport: "USD, EUR, GBP, CAD",
        tradingFees: "0.26% - 0.1%",
        btcPrice: "24315.75",
        ethPrice: "1844.18",
      },
      {
        name: "KuCoin",
        logo: "kucoin.png",
        url: "https://www.kucoin.com",
        country: "Seychelles",
        regulated: true,
        volume24h: "1800000000",
        markets: 200,
        trustScore: "4.3",
        fiatSupport: "USD, EUR",
        tradingFees: "0.1% - 0.05%",
        btcPrice: "24318.90",
        ethPrice: "1842.55",
      },
      {
        name: "Bitfinex",
        logo: "bitfinex.png",
        url: "https://www.bitfinex.com",
        country: "Hong Kong",
        regulated: true,
        volume24h: "1500000000",
        markets: 120,
        trustScore: "4.2",
        fiatSupport: "USD, EUR, JPY",
        tradingFees: "0.2% - 0.1%",
        btcPrice: "24320.15",
        ethPrice: "1843.10",
      },
    ];
    
    // Try to save these exchanges to the database
    try {
      for (const exchange of exchanges) {
        await storage.createExchange(exchange);
      }
    } catch (dbError) {
      console.error("Error saving exchanges to database:", dbError);
    }
    
    res.json(exchanges);
  } catch (error) {
    console.error("Error fetching exchanges:", error);
    res.status(500).json({ message: "Failed to fetch exchanges" });
  }
}

async function getConversionHistory(req: Request, res: Response) {
  try {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
    const history = await storage.getConversionHistory(limit);
    res.json(history);
  } catch (error) {
    console.error("Error fetching conversion history:", error);
    res.status(500).json({ message: "Failed to fetch conversion history" });
  }
}

// API sync functions for database seeding
async function syncForexCurrencies(req: Request, res: Response) {
  try {
    const EXCHANGE_RATE_API_KEY = process.env.VITE_EXCHANGE_RATE_API_KEY;
    const apiEndpoint = EXCHANGE_RATE_API_KEY 
      ? `https://v6.exchangerate-api.com/v6/${EXCHANGE_RATE_API_KEY}/latest/USD`
      : "https://v6.exchangerate-api.com/v6/demo/latest/USD";
    
    const response = await axios.get(apiEndpoint);
    if (response.data.result !== "success") {
      throw new Error("Failed to fetch forex rates");
    }
    
    // Transform response to our format
    const forexCurrencies = Object.entries(response.data.conversion_rates)
      .filter(([code]) => code !== "USD" && isValidForexCurrency(code)) 
      .map(([code, rate]) => {
        const percentChange24h = Math.random() * 2 - 1; // Random value between -1 and 1
        const percentChange7d = Math.random() * 4 - 2; // Random value between -2 and 2
        
        return {
          name: getCurrencyName(code),
          symbol: code,
          priceUsd: 1 / Number(rate), // Invert to get value in USD
          percentChange24h,
          percentChange7d,
          marketCapUsd: null,
          volumeUsd24h: null,
          type: "forex" as const,
        };
      })
      .sort((a, b) => b.priceUsd - a.priceUsd);
    
    // Save currencies to database
    const results = [];
    
    for (const currency of forexCurrencies) {
      try {
        // Check if the currency already exists
        const existingCurrencies = await storage.getCurrencies("forex");
        const existing = existingCurrencies.find(c => c.symbol === currency.symbol);
        
        if (existing) {
          // Update existing currency
          const updated = await storage.updateCurrency(existing.id, currency);
          if (updated) {
            results.push({ action: "updated", currency: updated });
          }
        } else {
          // Create new currency
          const created = await storage.createCurrency(currency);
          results.push({ action: "created", currency: created });
        }
      } catch (currencyError) {
        console.error(`Error processing currency ${currency.symbol}:`, currencyError);
        results.push({ action: "error", currency: currency.symbol, error: (currencyError as Error).message });
      }
    }
    
    res.json({ success: true, count: results.length, results });
  } catch (error) {
    console.error("Error syncing forex currencies:", error);
    res.status(500).json({ message: "Failed to sync forex currencies" });
  }
}

async function syncCryptoCurrencies(req: Request, res: Response) {
  try {
    const COIN_GECKO_API_KEY = process.env.VITE_COIN_GECKO_API_KEY;
    const headers = COIN_GECKO_API_KEY ? { 'x-cg-pro-api-key': COIN_GECKO_API_KEY } : {};
    const baseUrl = COIN_GECKO_API_KEY ? 'https://pro-api.coingecko.com/api/v3' : 'https://api.coingecko.com/api/v3';
    
    const apiUrl = `${baseUrl}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=false&price_change_percentage=24h,7d`;
    
    const response = await axios.get(apiUrl, { headers });
    
    const cryptoCurrencies = response.data.map((coin: any) => ({
      name: coin.name,
      symbol: coin.symbol.toUpperCase(),
      priceUsd: coin.current_price,
      percentChange24h: coin.price_change_percentage_24h || 0,
      percentChange7d: coin.price_change_percentage_7d_in_currency || 0,
      marketCapUsd: coin.market_cap,
      volumeUsd24h: coin.total_volume,
      type: "crypto" as const,
    }));
    
    // Save currencies to database
    const results = [];
    
    for (const currency of cryptoCurrencies) {
      try {
        // Check if the currency already exists
        const existingCurrencies = await storage.getCurrencies("crypto");
        const existing = existingCurrencies.find(c => c.symbol === currency.symbol);
        
        if (existing) {
          // Update existing currency
          const updated = await storage.updateCurrency(existing.id, currency);
          if (updated) {
            results.push({ action: "updated", currency: updated });
          }
        } else {
          // Create new currency
          const created = await storage.createCurrency(currency);
          results.push({ action: "created", currency: created });
        }
      } catch (currencyError) {
        console.error(`Error processing currency ${currency.symbol}:`, currencyError);
        results.push({ action: "error", currency: currency.symbol, error: (currencyError as Error).message });
      }
    }
    
    res.json({ success: true, count: results.length, results });
  } catch (error) {
    console.error("Error syncing crypto currencies:", error);
    res.status(500).json({ message: "Failed to sync crypto currencies" });
  }
}

async function syncExchanges(req: Request, res: Response) {
  try {
    // Default exchanges data
    const exchangesData = [
      {
        name: "Binance",
        logo: "binance.png",
        url: "https://www.binance.com",
        country: "Global",
        regulated: true,
        volume24h: "13200000000",
        markets: 350,
        trustScore: "4.8",
        fiatSupport: "USD, EUR, GBP, AUD",
        tradingFees: "0.1% - 0.02%",
        btcPrice: "24310.88",
        ethPrice: "1843.66",
      },
      {
        name: "Coinbase",
        logo: "coinbase.png",
        url: "https://www.coinbase.com",
        country: "United States",
        regulated: true,
        volume24h: "3800000000",
        markets: 150,
        trustScore: "4.5",
        fiatSupport: "USD, EUR, GBP",
        tradingFees: "0.6% - 0.1%",
        btcPrice: "24328.40",
        ethPrice: "1845.22",
      },
      {
        name: "Kraken",
        logo: "kraken.png",
        url: "https://www.kraken.com",
        country: "United States",
        regulated: true,
        volume24h: "2100000000",
        markets: 130,
        trustScore: "4.7",
        fiatSupport: "USD, EUR, GBP, CAD",
        tradingFees: "0.26% - 0.1%",
        btcPrice: "24315.75",
        ethPrice: "1844.18",
      },
      {
        name: "KuCoin",
        logo: "kucoin.png",
        url: "https://www.kucoin.com",
        country: "Seychelles",
        regulated: true,
        volume24h: "1800000000",
        markets: 200,
        trustScore: "4.3",
        fiatSupport: "USD, EUR",
        tradingFees: "0.1% - 0.05%",
        btcPrice: "24318.90",
        ethPrice: "1842.55",
      },
      {
        name: "Bitfinex",
        logo: "bitfinex.png",
        url: "https://www.bitfinex.com",
        country: "Hong Kong",
        regulated: true,
        volume24h: "1500000000",
        markets: 120,
        trustScore: "4.2",
        fiatSupport: "USD, EUR, JPY",
        tradingFees: "0.2% - 0.1%",
        btcPrice: "24320.15",
        ethPrice: "1843.10",
      },
    ];
    
    // Save exchanges to database
    const results = [];
    
    for (const exchange of exchangesData) {
      try {
        // Check if the exchange already exists
        const existingExchanges = await storage.getExchanges();
        const existing = existingExchanges.find(e => e.name === exchange.name);
        
        if (existing) {
          // Update existing exchange
          const updated = await storage.updateExchange(existing.id, exchange);
          if (updated) {
            results.push({ action: "updated", exchange: updated });
          }
        } else {
          // Create new exchange
          const created = await storage.createExchange(exchange);
          results.push({ action: "created", exchange: created });
        }
      } catch (exchangeError) {
        console.error(`Error processing exchange ${exchange.name}:`, exchangeError);
        results.push({ action: "error", exchange: exchange.name, error: (exchangeError as Error).message });
      }
    }
    
    res.json({ success: true, count: results.length, results });
  } catch (error) {
    console.error("Error syncing exchanges:", error);
    res.status(500).json({ message: "Failed to sync exchanges" });
  }
}

// Helper functions
function getExchangeRate(from: string, to: string): number {
  // In a real application, this would be fetched from an API
  const rates: Record<string, Record<string, number>> = {
    "USD": { "EUR": 0.93, "GBP": 0.81, "JPY": 149.54, "BTC": 0.000034, "ETH": 0.00055 },
    "EUR": { "USD": 1.08, "GBP": 0.87, "JPY": 161.42, "BTC": 0.000037, "ETH": 0.00059 },
    "GBP": { "USD": 1.24, "EUR": 1.15, "JPY": 185.90, "BTC": 0.000042, "ETH": 0.00068 },
    "BTC": { "USD": 29000, "EUR": 26950, "GBP": 23400 },
    "ETH": { "USD": 1800, "EUR": 1674, "GBP": 1458, "BTC": 0.062 }
  };

  if (rates[from] && rates[from][to]) {
    return rates[from][to];
  } else if (rates[to] && rates[to][from]) {
    return 1 / rates[to][from];
  }
  
  // Default fallback rate
  return 1.0;
}

// Helper function to get currency name from code
function getCurrencyName(code: string): string {
  const currencyNames: Record<string, string> = {
    USD: "US Dollar",
    EUR: "Euro",
    GBP: "British Pound",
    JPY: "Japanese Yen",
    CAD: "Canadian Dollar",
    AUD: "Australian Dollar",
    CHF: "Swiss Franc",
    CNY: "Chinese Yuan",
    HKD: "Hong Kong Dollar",
    NZD: "New Zealand Dollar",
    SEK: "Swedish Krona",
    NOK: "Norwegian Krone",
    SGD: "Singapore Dollar",
    INR: "Indian Rupee",
    BRL: "Brazilian Real",
    ZAR: "South African Rand",
    RUB: "Russian Ruble",
    MXN: "Mexican Peso",
    IDR: "Indonesian Rupiah",
    KRW: "South Korean Won",
    TRY: "Turkish Lira",
    THB: "Thai Baht",
    PLN: "Polish Złoty",
  };
  
  return currencyNames[code] || code;
}

// Helper function to check if a currency is a cryptocurrency
function isCrypto(symbol: string): boolean {
  const cryptoCurrencies = ['BTC', 'ETH', 'USDT', 'BNB', 'SOL', 'XRP', 'ADA', 'DOGE'];
  return cryptoCurrencies.includes(symbol);
}

// Helper function to get CoinGecko ID for a cryptocurrency
function getCoinGeckoId(symbol: string): string | null {
  const coinMap: Record<string, string> = {
    'BTC': 'bitcoin',
    'ETH': 'ethereum',
    'USDT': 'tether',
    'BNB': 'binancecoin',
    'SOL': 'solana',
    'XRP': 'ripple',
    'ADA': 'cardano',
    'DOGE': 'dogecoin'
  };
  
  return coinMap[symbol] || null;
}

// Helper function to validate forex currency code
function isValidForexCurrency(code: string): boolean {
  const validCurrencies = [
    'USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'CNY', 'HKD',
    'NZD', 'SEK', 'NOK', 'SGD', 'INR', 'BRL', 'ZAR', 'RUB', 'MXN',
    'IDR', 'KRW', 'TRY', 'THB', 'PLN'
  ];
  
  return validCurrencies.includes(code);
}
