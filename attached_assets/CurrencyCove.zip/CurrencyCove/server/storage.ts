import { 
  currencies, 
  conversionHistory, 
  exchanges,
  type Currency, 
  type ConversionHistory, 
  type Exchange,
  type InsertCurrency,
  type InsertConversionHistory,
  type InsertExchange
} from "@shared/schema";
import { db } from "./db";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  getCurrencies(type?: string): Promise<Currency[]>;
  getExchanges(): Promise<Exchange[]>;
  saveConversionHistory(conversion: InsertConversionHistory): Promise<ConversionHistory>;
  createCurrency(currency: InsertCurrency): Promise<Currency>;
  updateCurrency(id: number, currency: Partial<InsertCurrency>): Promise<Currency | undefined>;
  createExchange(exchange: InsertExchange): Promise<Exchange>;
  updateExchange(id: number, exchange: Partial<InsertExchange>): Promise<Exchange | undefined>;
  getConversionHistory(limit?: number): Promise<ConversionHistory[]>;
}

export class DatabaseStorage implements IStorage {
  async getCurrencies(type?: string): Promise<Currency[]> {
    try {
      if (type) {
        return await db.select().from(currencies).where(eq(currencies.type, type));
      }
      return await db.select().from(currencies);
    } catch (error) {
      console.error("Error fetching currencies from database:", error);
      return [];
    }
  }

  async getExchanges(): Promise<Exchange[]> {
    try {
      return await db.select().from(exchanges);
    } catch (error) {
      console.error("Error fetching exchanges from database:", error);
      return [];
    }
  }

  async saveConversionHistory(conversion: InsertConversionHistory): Promise<ConversionHistory> {
    try {
      const [result] = await db.insert(conversionHistory)
        .values({
          fromCurrency: conversion.fromCurrency,
          toCurrency: conversion.toCurrency,
          fromAmount: conversion.fromAmount.toString(),
          toAmount: conversion.toAmount.toString(),
          rate: conversion.rate.toString(),
          ipAddress: conversion.ipAddress || null
        })
        .returning();
      return result;
    } catch (error) {
      console.error("Error saving conversion history:", error);
      throw error;
    }
  }

  async createCurrency(currency: InsertCurrency): Promise<Currency> {
    try {
      const [result] = await db.insert(currencies).values({
        name: currency.name,
        symbol: currency.symbol,
        priceUsd: currency.priceUsd.toString(),
        percentChange24h: currency.percentChange24h ? currency.percentChange24h.toString() : null,
        percentChange7d: currency.percentChange7d ? currency.percentChange7d.toString() : null,
        marketCapUsd: currency.marketCapUsd ? currency.marketCapUsd.toString() : null,
        volumeUsd24h: currency.volumeUsd24h ? currency.volumeUsd24h.toString() : null,
        type: currency.type,
      }).returning();
      
      return result;
    } catch (error) {
      console.error("Error creating currency:", error);
      throw error;
    }
  }

  async updateCurrency(id: number, currencyData: Partial<InsertCurrency>): Promise<Currency | undefined> {
    try {
      // Convert numeric values to strings for database
      const dataToUpdate: Record<string, any> = {};
      
      if (currencyData.name) dataToUpdate.name = currencyData.name;
      if (currencyData.symbol) dataToUpdate.symbol = currencyData.symbol;
      if (currencyData.priceUsd !== undefined) dataToUpdate.priceUsd = currencyData.priceUsd.toString();
      if (currencyData.percentChange24h !== undefined) dataToUpdate.percentChange24h = currencyData.percentChange24h.toString();
      if (currencyData.percentChange7d !== undefined) dataToUpdate.percentChange7d = currencyData.percentChange7d.toString();
      if (currencyData.marketCapUsd !== undefined) dataToUpdate.marketCapUsd = currencyData.marketCapUsd.toString();
      if (currencyData.volumeUsd24h !== undefined) dataToUpdate.volumeUsd24h = currencyData.volumeUsd24h.toString();
      if (currencyData.type) dataToUpdate.type = currencyData.type;
      
      dataToUpdate.updatedAt = new Date();
      
      const [result] = await db.update(currencies)
        .set(dataToUpdate)
        .where(eq(currencies.id, id))
        .returning();
      
      return result;
    } catch (error) {
      console.error("Error updating currency:", error);
      return undefined;
    }
  }

  async createExchange(exchange: InsertExchange): Promise<Exchange> {
    try {
      const [result] = await db.insert(exchanges).values({
        name: exchange.name,
        logo: exchange.logo,
        url: exchange.url,
        country: exchange.country,
        regulated: exchange.regulated,
        volume24h: exchange.volume24h ? exchange.volume24h.toString() : null,
        markets: exchange.markets,
        trustScore: exchange.trustScore ? exchange.trustScore.toString() : null,
        fiatSupport: exchange.fiatSupport,
        tradingFees: exchange.tradingFees,
        btcPrice: exchange.btcPrice ? exchange.btcPrice.toString() : null,
        ethPrice: exchange.ethPrice ? exchange.ethPrice.toString() : null,
      }).returning();
      
      return result;
    } catch (error) {
      console.error("Error creating exchange:", error);
      throw error;
    }
  }

  async updateExchange(id: number, exchangeData: Partial<InsertExchange>): Promise<Exchange | undefined> {
    try {
      // Convert numeric values to strings for database
      const dataToUpdate: Record<string, any> = {};
      
      if (exchangeData.name) dataToUpdate.name = exchangeData.name;
      if (exchangeData.logo !== undefined) dataToUpdate.logo = exchangeData.logo;
      if (exchangeData.url) dataToUpdate.url = exchangeData.url;
      if (exchangeData.country !== undefined) dataToUpdate.country = exchangeData.country;
      if (exchangeData.regulated !== undefined) dataToUpdate.regulated = exchangeData.regulated;
      if (exchangeData.volume24h !== undefined) dataToUpdate.volume24h = exchangeData.volume24h.toString();
      if (exchangeData.markets !== undefined) dataToUpdate.markets = exchangeData.markets;
      if (exchangeData.trustScore !== undefined) dataToUpdate.trustScore = exchangeData.trustScore.toString();
      if (exchangeData.fiatSupport !== undefined) dataToUpdate.fiatSupport = exchangeData.fiatSupport;
      if (exchangeData.tradingFees !== undefined) dataToUpdate.tradingFees = exchangeData.tradingFees;
      if (exchangeData.btcPrice !== undefined) dataToUpdate.btcPrice = exchangeData.btcPrice.toString();
      if (exchangeData.ethPrice !== undefined) dataToUpdate.ethPrice = exchangeData.ethPrice.toString();
      
      dataToUpdate.updatedAt = new Date();
      
      const [result] = await db.update(exchanges)
        .set(dataToUpdate)
        .where(eq(exchanges.id, id))
        .returning();
      
      return result;
    } catch (error) {
      console.error("Error updating exchange:", error);
      return undefined;
    }
  }

  async getConversionHistory(limit: number = 50): Promise<ConversionHistory[]> {
    try {
      return await db.select()
        .from(conversionHistory)
        .orderBy(desc(conversionHistory.timestamp))
        .limit(limit);
    } catch (error) {
      console.error("Error fetching conversion history:", error);
      return [];
    }
  }
}

export const storage = new DatabaseStorage();
