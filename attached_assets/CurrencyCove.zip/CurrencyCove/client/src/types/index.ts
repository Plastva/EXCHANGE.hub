// Currency types
export type CurrencyType = "forex" | "crypto";

export interface Currency {
  id: string;
  name: string;
  symbol: string;
  priceUsd: number;
  percentChange24h: number;
  percentChange7d: number;
  marketCapUsd: number | null;
  volumeUsd24h: number | null;
}

export interface CurrencyOption {
  code: string;
  name: string;
  priceUsd?: number;
}

// Chart data
export interface ChartData {
  time: string;
  price: number;
}

// Exchange types
export interface Exchange {
  id: string;
  name: string;
  logo: string;
  url: string;
  country: string;
  regulated: boolean;
  volume24h: number;
  markets: number;
  trustScore: number;
  fiatSupport: string;
  tradingFees: string;
  btcPrice: number;
  ethPrice: number;
}
