import CurrencyConverter from "@/components/common/CurrencyConverter";
import CurrencyChart from "@/components/common/CurrencyChart";
import { FOREX_CURRENCIES, CRYPTO_CURRENCIES } from "@/lib/constants";
import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const Converter = () => {
  const [selectedCurrency, setSelectedCurrency] = useState("BTC");

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Advanced Currency Converter</h1>
        <p className="text-gray-600 mb-6">
          Convert between any fiat currency and cryptocurrency with real-time exchange rates.
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <CurrencyConverter
              title="Currency Converter"
              forexOptions={FOREX_CURRENCIES}
              cryptoOptions={CRYPTO_CURRENCIES}
              className="mb-8"
            />
            
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Conversion History</h2>
              <div className="text-gray-600 text-center py-8">
                Your recent conversions will appear here.
              </div>
            </div>
          </div>
          
          <div className="space-y-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-xl font-bold mb-4">Popular Conversions</h2>
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex justify-between mb-2">
                    <span>1 BTC</span>
                    <span className="font-medium">$24,312.40</span>
                  </div>
                  <div className="h-1 w-full bg-gray-200 rounded">
                    <div className="h-1 bg-primary rounded" style={{ width: '100%' }}></div>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex justify-between mb-2">
                    <span>1 ETH</span>
                    <span className="font-medium">$1,842.55</span>
                  </div>
                  <div className="h-1 w-full bg-gray-200 rounded">
                    <div className="h-1 bg-primary rounded" style={{ width: '75%' }}></div>
                  </div>
                </div>
                
                <div className="p-4 bg-gray-50 rounded-lg">
                  <div className="flex justify-between mb-2">
                    <span>1 EUR</span>
                    <span className="font-medium">$1.09</span>
                  </div>
                  <div className="h-1 w-full bg-gray-200 rounded">
                    <div className="h-1 bg-primary rounded" style={{ width: '25%' }}></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <Tabs defaultValue="forex">
                <div className="px-6 pt-6">
                  <h2 className="text-xl font-bold mb-4">Exchange Rates</h2>
                  <TabsList className="w-full">
                    <TabsTrigger value="forex" className="flex-1">Forex</TabsTrigger>
                    <TabsTrigger value="crypto" className="flex-1">Crypto</TabsTrigger>
                  </TabsList>
                </div>
                
                <TabsContent value="forex" className="px-6 pb-6 pt-2">
                  <div className="space-y-2">
                    {FOREX_CURRENCIES.slice(0, 5).map(currency => (
                      <div key={currency.code} className="flex justify-between py-2 border-b border-gray-100">
                        <span>{currency.code}</span>
                        <span className="font-medium">
                          {currency.code === "USD" ? "1.0000" : (Math.random() + 0.5).toFixed(4)}
                        </span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                <TabsContent value="crypto" className="px-6 pb-6 pt-2">
                  <div className="space-y-2">
                    {CRYPTO_CURRENCIES.slice(0, 5).map(currency => (
                      <div key={currency.code} className="flex justify-between py-2 border-b border-gray-100">
                        <span>{currency.code}</span>
                        <span className="font-medium">
                          ${currency.code === "BTC" 
                            ? (24000 + Math.random() * 1000).toFixed(2)
                            : (Math.random() * 1000 + 10).toFixed(2)
                          }
                        </span>
                      </div>
                    ))}
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
        
        <div className="mt-8">
          <CurrencyChart 
            currencySymbol={selectedCurrency} 
            title="Price Chart"
          />
        </div>
      </div>
    </div>
  );
};

export default Converter;
