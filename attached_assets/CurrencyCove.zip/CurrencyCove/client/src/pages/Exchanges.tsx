import { useExchanges } from "@/hooks/useCurrency";
import ExchangeCard from "@/components/common/ExchangeCard";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { formatCurrency } from "@/lib/utils";

const Exchanges = () => {
  const { 
    data: exchanges, 
    isLoading, 
    error 
  } = useExchanges();

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Top Cryptocurrency Exchanges</h1>
        <p className="text-gray-600 mb-6">
          Compare the most popular cryptocurrency exchanges by volume, features, and security.
        </p>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            <p className="col-span-3 text-center py-4">Loading exchanges...</p>
          ) : error ? (
            <p className="col-span-3 text-center py-4 text-red-500">Error loading exchanges. Please try again.</p>
          ) : exchanges?.length ? (
            exchanges.map(exchange => (
              <ExchangeCard key={exchange.id} exchange={exchange} />
            ))
          ) : (
            <p className="col-span-3 text-center py-4">No exchanges found.</p>
          )}
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Exchange Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Exchange</TableHead>
                    <TableHead>Trading Fee</TableHead>
                    <TableHead>BTC/USD</TableHead>
                    <TableHead>ETH/USD</TableHead>
                    <TableHead>Available Pairs</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4">Loading exchanges...</TableCell>
                    </TableRow>
                  ) : error ? (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4 text-red-500">Error loading exchanges. Please try again.</TableCell>
                    </TableRow>
                  ) : exchanges?.length ? (
                    exchanges.map(exchange => (
                      <TableRow key={exchange.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="flex items-center">
                            <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                              <span className="font-bold text-xs text-blue-800">{exchange.name.substring(0, 2).toUpperCase()}</span>
                            </div>
                            <div className="ml-3">
                              <div className="text-sm font-medium text-gray-900">{exchange.name}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-900">{exchange.tradingFees}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm font-medium text-gray-900">{formatCurrency(exchange.btcPrice, 2)}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm font-medium text-gray-900">{formatCurrency(exchange.ethPrice, 2)}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm text-gray-900">{exchange.markets}+</div>
                        </TableCell>
                        <TableCell>
                          <a 
                            href={exchange.url} 
                            target="_blank" 
                            rel="noopener noreferrer" 
                            className="text-primary hover:text-primary/90 text-sm"
                          >
                            Trade
                          </a>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={6} className="text-center py-4">No exchanges found.</TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Exchanges;
