import { useState } from "react";
import { useAllCurrencies } from "@/hooks/useCurrency";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowUp, ArrowDown, Search } from "lucide-react";
import { Link } from "wouter";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { CurrencyType } from "@/types";
import { CurrencyIcons } from "@/components/icons/CurrencyIcons";

type SortField = "name" | "price" | "change" | "marketCap";
type SortDirection = "asc" | "desc";

const AllCurrencies = () => {
  const [currencyType, setCurrencyType] = useState<CurrencyType | undefined>(undefined);
  const [searchTerm, setSearchTerm] = useState("");
  const [sortField, setSortField] = useState<SortField>("marketCap");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  
  const { 
    data: currencies, 
    isLoading, 
    error 
  } = useAllCurrencies(currencyType);

  // Filter and sort currencies
  const filteredCurrencies = currencies
    ? currencies
        .filter(currency =>
          currency.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          currency.symbol.toLowerCase().includes(searchTerm.toLowerCase())
        )
        .sort((a, b) => {
          let comparison = 0;
          switch (sortField) {
            case "name":
              comparison = a.name.localeCompare(b.name);
              break;
            case "price":
              comparison = a.priceUsd - b.priceUsd;
              break;
            case "change":
              comparison = a.percentChange24h - b.percentChange24h;
              break;
            case "marketCap":
              comparison = (a.marketCapUsd || 0) - (b.marketCapUsd || 0);
              break;
          }
          return sortDirection === "asc" ? comparison : -comparison;
        })
    : [];

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <CardTitle className="text-2xl font-bold text-gray-800 mb-4 md:mb-0">All Currencies</CardTitle>
            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 w-full md:w-auto">
              <div className="relative flex-grow">
                <Input
                  type="text"
                  placeholder="Search currencies..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 pr-4 py-2 w-full"
                />
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
              </div>
              
              <Select
                value={currencyType || "all"}
                onValueChange={(value) => setCurrencyType(value === "all" ? undefined : value as CurrencyType)}
              >
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="forex">Forex Only</SelectItem>
                  <SelectItem value="crypto">Crypto Only</SelectItem>
                </SelectContent>
              </Select>
              
              <Select
                value={`${sortField}-${sortDirection}`}
                onValueChange={(value) => {
                  const [field, direction] = value.split("-");
                  setSortField(field as SortField);
                  setSortDirection(direction as SortDirection);
                }}
              >
                <SelectTrigger className="w-full sm:w-[220px]">
                  <SelectValue placeholder="Sort By" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="marketCap-desc">Sort By: Market Cap</SelectItem>
                  <SelectItem value="name-asc">Sort By: Name (A-Z)</SelectItem>
                  <SelectItem value="price-desc">Sort By: Price (High-Low)</SelectItem>
                  <SelectItem value="price-asc">Sort By: Price (Low-High)</SelectItem>
                  <SelectItem value="change-desc">Sort By: Change (High-Low)</SelectItem>
                  <SelectItem value="change-asc">Sort By: Change (Low-High)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Currency</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Price (USD)</TableHead>
                  <TableHead>24h Change</TableHead>
                  <TableHead>Market Cap</TableHead>
                  <TableHead>Chart</TableHead>
                  <TableHead className="text-right">Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      <div className="flex justify-center items-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Loading...
                      </div>
                    </TableCell>
                  </TableRow>
                ) : error ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center text-red-500">
                      Error loading data. Please try again.
                    </TableCell>
                  </TableRow>
                ) : filteredCurrencies.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="h-24 text-center">
                      No currencies found.
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredCurrencies.map((currency) => {
                    const isCrypto = !!currency.marketCapUsd;

                    return (
                      <TableRow key={currency.id} className="hover:bg-gray-50">
                        <TableCell>
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center">
                              {CurrencyIcons[currency.symbol] || (
                                <div className={`h-8 w-8 flex items-center justify-center rounded-full ${
                                  isCrypto ? "bg-indigo-100 text-indigo-800" : "bg-blue-100 text-blue-800"
                                } font-bold text-sm`}>
                                  {currency.symbol.substring(0, 1)}
                                </div>
                              )}
                            </div>
                            <div className="ml-4">
                              <div className="font-medium text-gray-900">{currency.symbol}</div>
                              <div className="text-sm text-gray-500">{currency.name}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant={isCrypto ? "secondary" : "outline"} className={isCrypto ? "bg-indigo-100 text-indigo-800" : "bg-blue-100 text-blue-800"}>
                            {isCrypto ? "Crypto" : "Forex"}
                          </Badge>
                        </TableCell>
                        <TableCell className="whitespace-nowrap">
                          {formatCurrency(currency.priceUsd, isCrypto ? 2 : 4, currency.symbol === "BTC" ? "₿" : "$")}
                        </TableCell>
                        <TableCell className={currency.percentChange24h >= 0 ? "text-green-600" : "text-red-600"}>
                          <div className="flex items-center">
                            {currency.percentChange24h >= 0 ? (
                              <ArrowUp className="h-4 w-4 mr-1" />
                            ) : (
                              <ArrowDown className="h-4 w-4 mr-1" />
                            )}
                            {formatPercentage(currency.percentChange24h)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {currency.marketCapUsd ? formatCurrency(currency.marketCapUsd, 0, "$") : "-"}
                        </TableCell>
                        <TableCell>
                          <div className="h-8 w-24 bg-gray-100 rounded overflow-hidden">
                            {/* Chart placeholder */}
                            <div className="h-full w-full flex items-center justify-center text-xs text-gray-500">Chart View</div>
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <Link href="/converter">
                            <Button variant="ghost" className="text-primary hover:text-primary/90">
                              Convert
                            </Button>
                          </Link>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
          
          <div className="mt-6 flex items-center justify-between flex-wrap">
            <div className="text-sm text-gray-700">
              Showing <span className="font-medium">1</span> to <span className="font-medium">{filteredCurrencies.length}</span> of <span className="font-medium">{filteredCurrencies.length}</span> results
            </div>
            <div className="flex space-x-1">
              <Button variant="outline" size="sm" disabled>
                Previous
              </Button>
              <Button variant="default" size="sm" className="px-4 py-2">
                1
              </Button>
              <Button variant="outline" size="sm" disabled>
                Next
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AllCurrencies;
