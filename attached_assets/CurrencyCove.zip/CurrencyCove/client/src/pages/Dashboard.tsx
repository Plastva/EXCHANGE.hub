import { useForexCurrencies, useCryptoCurrencies } from "@/hooks/useCurrency";
import CurrencyConverter from "@/components/common/CurrencyConverter";
import MarketTable from "@/components/common/MarketTable";
import CurrencyChart from "@/components/common/CurrencyChart";
import { FOREX_CURRENCIES, CRYPTO_CURRENCIES } from "@/lib/constants";
import { ArrowUpDown, BarChart3, RefreshCw } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

const Dashboard = () => {
  const { t } = useLanguage();
  const { 
    data: forexData, 
    isLoading: isForexLoading, 
    error: forexError 
  } = useForexCurrencies();
  
  const { 
    data: cryptoData, 
    isLoading: isCryptoLoading, 
    error: cryptoError 
  } = useCryptoCurrencies();

  const handleGetStarted = () => {
    // Scroll to the converter section
    const converterElement = document.getElementById('quick-converter');
    if (converterElement) {
      converterElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-10">
        <h1 className="text-3xl font-bold text-gray-900 sm:text-4xl mb-4">
          Real-Time Currency & Crypto Exchange
        </h1>
        <p className="max-w-2xl mx-auto text-lg text-gray-500">
          Monitor live forex and cryptocurrency rates and convert between currencies instantly.
        </p>
      </div>

      {/* Featured Banner */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl shadow-xl overflow-hidden mb-10">
        <div className="md:flex">
          <div className="p-8 md:p-12 md:w-1/2">
            <h2 className="text-white text-3xl font-bold mb-4">{t("startTrading")}</h2>
            <p className="text-blue-100 mb-6">
              Get real-time data and seamless conversion between all major fiat and cryptocurrencies.
            </p>
            <button 
              onClick={handleGetStarted}
              className="bg-white text-blue-600 font-semibold py-2 px-6 rounded-lg shadow hover:bg-blue-50 transition duration-200"
            >
              {t("getStarted")}
            </button>
          </div>
          <div className="md:w-1/2">
            <img
              src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=500&q=80"
              alt="Financial dashboard with currency data"
              className="h-full w-full object-cover"
            />
          </div>
        </div>
      </div>

      {/* Market Overview */}
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Market Overview</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {/* Forex Card */}
          <MarketTable
            title={t("forexHighlights")}
            type="forex"
            data={forexData || []}
            isLoading={isForexLoading}
            error={forexError}
            showViewAll={true}
            viewAllLink="/forex"
            limit={4}
          />

          {/* Crypto Card */}
          <MarketTable
            title={t("cryptoHighlights")}
            type="crypto"
            data={cryptoData || []}
            isLoading={isCryptoLoading}
            error={cryptoError}
            showViewAll={true}
            viewAllLink="/crypto"
            limit={4}
          />
        </div>
        
        {/* Quick Converter Card */}
        <div id="quick-converter">
          <CurrencyConverter
            title={t("quickCurrencyConverter")}
            forexOptions={FOREX_CURRENCIES}
            cryptoOptions={CRYPTO_CURRENCIES}
            className="mb-12"
          />
        </div>
        
        {/* Market Trends Chart */}
        <CurrencyChart currencySymbol="BTC" title={t("marketTrends")} />
        
        {/* Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-10">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-primary mb-4">
              <BarChart3 className="h-10 w-10" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{t("realTimeData")}</h3>
            <p className="text-gray-600">
              Get access to live exchange rates for all major currencies and cryptocurrencies updated every minute.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-primary mb-4">
              <ArrowUpDown className="h-10 w-10" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{t("easyConversion")}</h3>
            <p className="text-gray-600">
              Convert between any fiat or cryptocurrency with our simple and intuitive converter tool.
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="text-primary mb-4">
              <RefreshCw className="h-10 w-10" />
            </div>
            <h3 className="text-lg font-semibold mb-2">{t("comprehensiveCharts")}</h3>
            <p className="text-gray-600">
              View detailed charts from Coinbase, CoinMarketCap, and DexScreener for in-depth analysis.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
