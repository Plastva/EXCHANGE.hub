import { useState } from "react";
import { useCryptoCurrencies } from "@/hooks/useCurrency";
import MarketTable from "@/components/common/MarketTable";
import CurrencyChart from "@/components/common/CurrencyChart";

const Crypto = () => {
  const [selectedCurrency, setSelectedCurrency] = useState("BTC");
  
  const { 
    data: cryptoData, 
    isLoading: isCryptoLoading, 
    error: cryptoError 
  } = useCryptoCurrencies();

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Cryptocurrency Markets</h1>
        <p className="text-gray-600 mb-6">
          Live prices and charts for the world's top cryptocurrencies.
        </p>
        
        <MarketTable
          title="Top Cryptocurrencies"
          type="crypto"
          data={cryptoData || []}
          isLoading={isCryptoLoading}
          error={cryptoError}
          showSearch={true}
          showPagination={true}
        />
        
        <div className="mt-8">
          <CurrencyChart 
            currencySymbol={selectedCurrency} 
            title={`${selectedCurrency} Chart`} 
          />
        </div>
      </div>
    </div>
  );
};

export default Crypto;
