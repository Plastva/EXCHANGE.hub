import { useState } from "react";
import { useForexCurrencies } from "@/hooks/useCurrency";
import MarketTable from "@/components/common/MarketTable";
import CurrencyChart from "@/components/common/CurrencyChart";

const Forex = () => {
  const [selectedCurrency, setSelectedCurrency] = useState("EUR");
  
  const { 
    data: forexData, 
    isLoading: isForexLoading, 
    error: forexError 
  } = useForexCurrencies();

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Forex Markets</h1>
        <p className="text-gray-600 mb-6">
          Live exchange rates and charts for the world's top forex currencies.
        </p>
        
        <MarketTable
          title="Major Forex Pairs"
          type="forex"
          data={forexData || []}
          isLoading={isForexLoading}
          error={forexError}
          showSearch={true}
          showPagination={true}
        />
        
        <div className="mt-8">
          <CurrencyChart 
            currencySymbol={selectedCurrency} 
            title={`${selectedCurrency}/USD Chart`} 
          />
        </div>
      </div>
    </div>
  );
};

export default Forex;
