import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { ArrowUp, ArrowDown } from "lucide-react";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { Currency } from "@/types";
import { CurrencyIcons } from "@/components/icons/CurrencyIcons";

interface CurrencyCardProps {
  currency: Currency;
  type: "forex" | "crypto";
}

const CurrencyCard = ({ currency, type }: CurrencyCardProps) => {
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow duration-300">
      <div className={`p-4 border-b border-gray-100 ${type === "forex" ? "bg-blue-50" : "bg-indigo-50"}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center">
              {CurrencyIcons[currency.symbol] || (
                <div className={`h-8 w-8 flex items-center justify-center rounded-full ${
                  type === "crypto" ? "bg-indigo-100 text-indigo-800" : "bg-blue-100 text-blue-800"
                } font-bold text-sm`}>
                  {currency.symbol.substring(0, 1)}
                </div>
              )}
            </div>
            <div className="ml-3">
              <h3 className="font-medium text-gray-900">{currency.symbol}</h3>
              <span className="text-xs text-gray-500">{currency.name}</span>
            </div>
          </div>
          <div>
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
              type === "forex" ? "bg-blue-100 text-blue-800" : "bg-indigo-100 text-indigo-800"
            }`}>
              {type === "forex" ? "Forex" : "Crypto"}
            </span>
          </div>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">Price:</span>
            <span className="text-sm font-medium">
              {formatCurrency(currency.priceUsd, type === "forex" ? 4 : 2, currency.symbol === "BTC" ? "₿" : "$")}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-sm text-gray-500">24h Change:</span>
            <span className={`text-sm font-medium flex items-center ${
              currency.percentChange24h >= 0 ? "text-green-600" : "text-red-600"
            }`}>
              {currency.percentChange24h >= 0 ? (
                <ArrowUp className="h-3 w-3 mr-1" />
              ) : (
                <ArrowDown className="h-3 w-3 mr-1" />
              )}
              {formatPercentage(currency.percentChange24h)}
            </span>
          </div>
          {type === "crypto" ? (
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Market Cap:</span>
              <span className="text-sm font-medium">
                {currency.marketCapUsd ? formatCurrency(currency.marketCapUsd, 0, "$") : "-"}
              </span>
            </div>
          ) : (
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">7d Change:</span>
              <span className={`text-sm font-medium flex items-center ${
                currency.percentChange7d >= 0 ? "text-green-600" : "text-red-600"
              }`}>
                {currency.percentChange7d >= 0 ? (
                  <ArrowUp className="h-3 w-3 mr-1" />
                ) : (
                  <ArrowDown className="h-3 w-3 mr-1" />
                )}
                {formatPercentage(currency.percentChange7d)}
              </span>
            </div>
          )}
        </div>
        <div className="mt-4 flex justify-between">
          <Link href={`/${type}/${currency.symbol}`}>
            <a className="text-primary hover:text-primary/90 text-sm font-medium">View Chart</a>
          </Link>
          <Link href="/converter">
            <a className="text-primary hover:text-primary/90 text-sm font-medium">Convert</a>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
};

export default CurrencyCard;
