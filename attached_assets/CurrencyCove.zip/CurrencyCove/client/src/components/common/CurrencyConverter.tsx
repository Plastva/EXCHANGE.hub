import { useState, useEffect } from "react";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ArrowUpDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useCurrencyConversion } from "@/hooks/useCurrency";
import { formatCurrency } from "@/lib/utils";
import { CurrencyOption } from "@/types";
import { useLanguage } from "@/contexts/LanguageContext";
import { CurrencyIcons } from "@/components/icons/CurrencyIcons";

interface CurrencyConverterProps {
  title?: string;
  forexOptions?: CurrencyOption[];
  cryptoOptions?: CurrencyOption[];
  className?: string;
}

const CurrencyConverter = ({ 
  title = "Currency Converter", 
  forexOptions = [],
  cryptoOptions = [],
  className = ""
}: CurrencyConverterProps) => {
  const { toast } = useToast();
  const { t } = useLanguage();
  const [fromAmount, setFromAmount] = useState<string>("1");
  const [fromCurrency, setFromCurrency] = useState<string>("USD");
  const [toCurrency, setToCurrency] = useState<string>("EUR");
  const [toAmount, setToAmount] = useState<string>("");
  
  const allOptions = [...forexOptions, ...cryptoOptions];
  
  const { data: conversionData, isLoading, error } = useCurrencyConversion(
    fromCurrency, 
    toCurrency, 
    parseFloat(fromAmount || "0")
  );

  useEffect(() => {
    if (conversionData) {
      setToAmount(conversionData.convertedAmount.toString());
    }
  }, [conversionData]);

  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: "Failed to convert currency. Please try again.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const handleSwapCurrencies = () => {
    setFromCurrency(toCurrency);
    setToCurrency(fromCurrency);
  };

  const handleFromAmountChange = (value: string) => {
    // Allow only numbers and decimal point
    if (/^$|^[0-9]*\.?[0-9]*$/.test(value)) {
      setFromAmount(value);
    }
  };

  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="space-y-4">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-1">{t("from")}</Label>
              <div className="mt-1 relative rounded-md shadow-sm flex">
                <Select value={fromCurrency} onValueChange={setFromCurrency}>
                  <SelectTrigger className="w-1/3 rounded-r-none">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {allOptions.map((option) => (
                      <SelectItem key={option.code} value={option.code}>
                        <div className="flex items-center">
                          <span className="w-6 h-6 mr-2">
                            {CurrencyIcons[option.code] || option.code.substring(0, 1)}
                          </span>
                          {option.code}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="text"
                  value={fromAmount}
                  onChange={(e) => handleFromAmountChange(e.target.value)}
                  className="w-2/3 rounded-l-none"
                />
              </div>
            </div>
            
            <div className="flex justify-center">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={handleSwapCurrencies}
                className="w-8 h-8 rounded-full"
              >
                <ArrowUpDown className="h-4 w-4" />
              </Button>
            </div>
            
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-1">{t("to")}</Label>
              <div className="mt-1 relative rounded-md shadow-sm flex">
                <Select value={toCurrency} onValueChange={setToCurrency}>
                  <SelectTrigger className="w-1/3 rounded-r-none">
                    <SelectValue placeholder="Select currency" />
                  </SelectTrigger>
                  <SelectContent>
                    {allOptions.map((option) => (
                      <SelectItem key={option.code} value={option.code}>
                        <div className="flex items-center">
                          <span className="w-6 h-6 mr-2">
                            {CurrencyIcons[option.code] || option.code.substring(0, 1)}
                          </span>
                          {option.code}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Input
                  type="text"
                  value={isLoading ? "Loading..." : toAmount}
                  readOnly
                  className="w-2/3 rounded-l-none"
                />
              </div>
            </div>
          </div>
          
          <div className="bg-gray-50 dark:bg-gray-800 p-5 rounded-lg shadow-sm">
            <h3 className="font-medium text-gray-800 dark:text-gray-200 mb-3">{t("exchangeDetails")}</h3>
            {isLoading ? (
              <div className="animate-pulse flex flex-col space-y-3">
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
                <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-5/6"></div>
              </div>
            ) : error ? (
              <div className="text-red-500 py-2 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                {t("errorLoadingData")}
              </div>
            ) : (
              <div className="text-sm space-y-2">
                <div className="flex justify-between border-b dark:border-gray-700 pb-2">
                  <span className="text-gray-600 dark:text-gray-400">{t("rate")}:</span>
                  <span className="font-medium dark:text-white">
                    {conversionData ? 
                      `1 ${fromCurrency} = ${formatCurrency(conversionData.rate)} ${toCurrency}` : 
                      "N/A"}
                  </span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-gray-600 dark:text-gray-400">{t("fee")}:</span>
                  <span className="font-medium text-green-600 dark:text-green-400">0%</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-gray-600 dark:text-gray-400">{t("delivery")}:</span>
                  <span className="font-medium dark:text-white">Instant</span>
                </div>
                <div className="pt-2 border-t border-gray-200 dark:border-gray-700 mt-1">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">{t("lastUpdated")}:</span>
                    <span className="font-medium dark:text-white">
                      {conversionData ? new Date().toLocaleTimeString() : "N/A"}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          <div className="bg-gradient-to-br from-primary/90 to-primary text-white p-5 rounded-lg shadow-sm flex flex-col justify-between">
            <div>
              <h3 className="font-medium mb-3">{t("popularConversions")}</h3>
              {isLoading ? (
                <div className="animate-pulse space-y-3">
                  <div className="h-4 bg-white/20 rounded w-full"></div>
                  <div className="h-4 bg-white/20 rounded w-full"></div>
                  <div className="h-4 bg-white/20 rounded w-full"></div>
                </div>
              ) : (
                <ul className="space-y-3 text-sm">
                  <li className="flex justify-between items-center p-2 rounded bg-white/10">
                    <div className="flex items-center">
                      {CurrencyIcons["BTC"]}
                      <span className="ml-2">1 BTC = </span>
                    </div>
                    <span className="font-medium">
                      {allOptions.find(o => o.code === "BTC")?.priceUsd ? 
                        formatCurrency(Number(allOptions.find(o => o.code === "BTC")?.priceUsd)) + " USD" : 
                        "N/A"}
                    </span>
                  </li>
                  <li className="flex justify-between items-center p-2 rounded bg-white/10">
                    <div className="flex items-center">
                      {CurrencyIcons["ETH"]}
                      <span className="ml-2">1 ETH = </span>
                    </div>
                    <span className="font-medium">
                      {allOptions.find(o => o.code === "ETH")?.priceUsd ? 
                        formatCurrency(Number(allOptions.find(o => o.code === "ETH")?.priceUsd)) + " USD" : 
                        "N/A"}
                    </span>
                  </li>
                  <li className="flex justify-between items-center p-2 rounded bg-white/10">
                    <div className="flex items-center">
                      {CurrencyIcons["EUR"]}
                      <span className="ml-2">1 EUR = </span>
                    </div>
                    <span className="font-medium">
                      {allOptions.find(o => o.code === "EUR")?.priceUsd ? 
                        formatCurrency(1 / Number(allOptions.find(o => o.code === "EUR")?.priceUsd)) + " USD" : 
                        "N/A"}
                    </span>
                  </li>
                </ul>
              )}
            </div>
            <Button className="mt-4 bg-white text-primary hover:bg-gray-100 transition duration-150">
              {t("convertNow")}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CurrencyConverter;
