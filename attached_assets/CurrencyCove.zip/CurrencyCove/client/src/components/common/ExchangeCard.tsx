import { Card, CardContent } from "@/components/ui/card";
import { StarIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Exchange } from "@/types";
import { formatCurrency } from "@/lib/utils";

interface ExchangeCardProps {
  exchange: Exchange;
}

const ExchangeCard = ({ exchange }: ExchangeCardProps) => {
  const renderTrustScore = (score: number) => {
    const fullStars = Math.floor(score);
    const hasHalfStar = score % 1 >= 0.5;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(
        <StarIcon
          key={`full-${i}`}
          className="h-4 w-4 text-yellow-400 fill-current"
        />
      );
    }

    if (hasHalfStar) {
      stars.push(
        <div key="half" className="relative">
          <StarIcon className="h-4 w-4 text-yellow-400" />
          <div className="absolute inset-0 overflow-hidden w-1/2">
            <StarIcon className="h-4 w-4 text-yellow-400 fill-current" />
          </div>
        </div>
      );
    }

    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(
        <StarIcon
          key={`empty-${i}`}
          className="h-4 w-4 text-yellow-400 opacity-50"
        />
      );
    }

    return <div className="flex">{stars}</div>;
  };

  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow duration-300">
      <div className="p-4 border-b border-gray-200 bg-gray-50 flex items-center justify-between">
        <div className="flex items-center">
          <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
            <span className="font-bold text-blue-800">{exchange.name.substring(0, 2).toUpperCase()}</span>
          </div>
          <div className="ml-3">
            <h3 className="font-medium text-gray-900">{exchange.name}</h3>
            <span className="text-xs text-gray-500">{exchange.country}</span>
          </div>
        </div>
        {exchange.regulated && (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            Regulated
          </span>
        )}
      </div>
      <CardContent className="p-4">
        <div className="space-y-2">
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-500">Trading Volume (24h)</span>
            <span className="text-sm font-medium">{formatCurrency(exchange.volume24h, 2, "$")}</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-500">Markets</span>
            <span className="text-sm font-medium">{exchange.markets}+</span>
          </div>
          <div className="flex justify-between mb-2">
            <span className="text-sm text-gray-500">Trust Score</span>
            <div className="flex">
              {renderTrustScore(exchange.trustScore)}
            </div>
          </div>
          <div className="flex justify-between mb-4">
            <span className="text-sm text-gray-500">Fiat Support</span>
            <span className="text-sm font-medium">{exchange.fiatSupport}</span>
          </div>
          <a 
            href={exchange.url} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="block w-full"
          >
            <Button className="w-full">
              Visit Exchange
            </Button>
          </a>
        </div>
      </CardContent>
    </Card>
  );
};

export default ExchangeCard;
