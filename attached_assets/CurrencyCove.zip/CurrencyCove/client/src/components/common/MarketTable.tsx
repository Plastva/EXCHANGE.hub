import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ArrowUp, ArrowDown, Search } from "lucide-react";
import { Link } from "wouter";
import { formatCurrency, formatPercentage } from "@/lib/utils";
import { CurrencyType, Currency } from "@/types";
import { CurrencyIcons } from "@/components/icons/CurrencyIcons";

interface MarketTableProps {
  title: string;
  description?: string;
  type: CurrencyType;
  data: Currency[];
  isLoading: boolean;
  error: any;
  showPagination?: boolean;
  showViewAll?: boolean;
  viewAllLink?: string;
  showSearch?: boolean;
  limit?: number;
}

const MarketTable = ({
  title,
  description,
  type,
  data,
  isLoading,
  error,
  showPagination = false,
  showViewAll = false,
  viewAllLink = type === "forex" ? "/forex" : "/crypto",
  showSearch = false,
  limit = 10
}: MarketTableProps) => {
  const [searchTerm, setSearchTerm] = useState("");

  // Filter data based on search term
  const filteredData = data
    .filter((item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.symbol.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .slice(0, limit);

  const renderLoadingState = () => (
    <TableRow>
      <TableCell colSpan={type === "forex" ? 5 : 6} className="h-24 text-center">
        <div className="flex justify-center items-center">
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Loading...
        </div>
      </TableCell>
    </TableRow>
  );

  const renderErrorState = () => (
    <TableRow>
      <TableCell colSpan={type === "forex" ? 5 : 6} className="h-24 text-center text-red-500">
        Error loading data. Please try again.
      </TableCell>
    </TableRow>
  );

  const renderEmptyState = () => (
    <TableRow>
      <TableCell colSpan={type === "forex" ? 5 : 6} className="h-24 text-center">
        No currencies found.
      </TableCell>
    </TableRow>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
          <div>
            <CardTitle>{title}</CardTitle>
            {description && <CardDescription>{description}</CardDescription>}
          </div>
          {showSearch && (
            <div className="relative mt-4 md:mt-0">
              <Input
                placeholder={`Search ${type}...`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 w-full md:w-auto"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
            </div>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{type === "forex" ? "Currency" : "Cryptocurrency"}</TableHead>
                <TableHead>{type === "forex" ? "Price (USD)" : "Price"}</TableHead>
                <TableHead>24h Change</TableHead>
                {type === "forex" ? (
                  <TableHead>Weekly Change</TableHead>
                ) : (
                  <>
                    <TableHead>Market Cap</TableHead>
                    <TableHead>Volume (24h)</TableHead>
                  </>
                )}
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                renderLoadingState()
              ) : error ? (
                renderErrorState()
              ) : filteredData.length === 0 ? (
                renderEmptyState()
              ) : (
                filteredData.map((currency) => (
                  <TableRow key={currency.id} className="hover:bg-gray-50">
                    <TableCell>
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 flex items-center justify-center">
                          {CurrencyIcons[currency.symbol] || (
                            <div className={`h-8 w-8 flex items-center justify-center rounded-full ${
                              type === "crypto" ? "bg-indigo-100 text-indigo-800" : "bg-blue-100 text-blue-800"
                            } font-bold text-sm`}>
                              {currency.symbol.substring(0, 1)}
                            </div>
                          )}
                        </div>
                        <div className="ml-4">
                          <div className="font-medium text-gray-900">{currency.symbol}</div>
                          <div className="text-sm text-gray-500">{currency.name}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="whitespace-nowrap">
                      {formatCurrency(currency.priceUsd, type === "forex" ? 4 : 2, currency.symbol === "BTC" ? "₿" : "$")}
                    </TableCell>
                    <TableCell className={currency.percentChange24h >= 0 ? "text-green-600" : "text-red-600"}>
                      <div className="flex items-center">
                        {currency.percentChange24h >= 0 ? (
                          <ArrowUp className="h-4 w-4 mr-1" />
                        ) : (
                          <ArrowDown className="h-4 w-4 mr-1" />
                        )}
                        {formatPercentage(currency.percentChange24h)}
                      </div>
                    </TableCell>
                    {type === "forex" ? (
                      <TableCell className={currency.percentChange7d >= 0 ? "text-green-600" : "text-red-600"}>
                        <div className="flex items-center">
                          {currency.percentChange7d >= 0 ? (
                            <ArrowUp className="h-4 w-4 mr-1" />
                          ) : (
                            <ArrowDown className="h-4 w-4 mr-1" />
                          )}
                          {formatPercentage(currency.percentChange7d)}
                        </div>
                      </TableCell>
                    ) : (
                      <>
                        <TableCell>
                          {currency.marketCapUsd ? formatCurrency(currency.marketCapUsd, 0, "$") : "-"}
                        </TableCell>
                        <TableCell>
                          {currency.volumeUsd24h ? formatCurrency(currency.volumeUsd24h, 0, "$") : "-"}
                        </TableCell>
                      </>
                    )}
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button variant="ghost" className="text-primary hover:text-primary/90">
                          View Chart
                        </Button>
                        <Link href="/converter">
                          <Button variant="ghost" className="text-primary hover:text-primary/90">
                            Convert
                          </Button>
                        </Link>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
      {(showPagination || showViewAll) && (
        <CardFooter className="flex justify-between items-center">
          {showPagination ? (
            <div className="flex items-center justify-between w-full">
              <div className="text-sm text-gray-700">
                Showing <span className="font-medium">1</span> to <span className="font-medium">{filteredData.length}</span> of <span className="font-medium">{data.length}</span> results
              </div>
              <div className="flex space-x-1">
                <Button variant="outline" size="sm" disabled>
                  Previous
                </Button>
                <Button variant="outline" size="sm" className="px-4 py-2">
                  1
                </Button>
                <Button variant="outline" size="sm" className="px-4 py-2">
                  2
                </Button>
                <Button variant="outline" size="sm" className="px-4 py-2">
                  3
                </Button>
                <Button variant="outline" size="sm">
                  Next
                </Button>
              </div>
            </div>
          ) : showViewAll ? (
            <div className="flex justify-end w-full">
              <Link href={viewAllLink}>
                <Button variant="link" className="text-primary">
                  View All {type === "forex" ? "Forex Currencies" : "Cryptocurrencies"}
                </Button>
              </Link>
            </div>
          ) : null}
        </CardFooter>
      )}
    </Card>
  );
};

export default MarketTable;
