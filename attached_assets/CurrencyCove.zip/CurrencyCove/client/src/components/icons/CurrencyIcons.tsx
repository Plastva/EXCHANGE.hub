import React from "react";

const BitcoinIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-orange-100 text-orange-800 p-1">
    <path
      fill="currentColor"
      d="M23.638 14.904c-1.602 6.43-8.113 10.34-14.542 8.736C2.67 22.05-1.244 15.525.362 9.105 1.962 2.67 8.475-1.243 14.9.358c6.43 1.605 10.342 8.115 8.738 14.548v-.002zm-6.35-4.613c.24-1.59-.974-2.45-2.64-3.03l.54-2.153-1.315-.33-.525 2.107c-.345-.087-.705-.167-1.064-.25l.526-2.127-1.32-.33-.54 2.165c-.285-.067-.565-.132-.84-.2l-1.815-.45-.35 1.4s.975.225.955.236c.535.136.63.486.615.766l-1.477 5.92c-.075.166-.24.406-.614.314.015.02-.96-.24-.96-.24l-.66 1.51 1.71.426.93.242-.54 2.19 1.32.327.54-2.17c.36.1.705.19 1.05.273l-.51 2.154 1.32.33.545-2.19c2.24.427 3.93.257 4.64-1.774.57-1.637-.03-2.577-1.217-3.196.854-.193 1.5-.76 1.68-1.93h.01zm-3.01 4.22c-.404 1.64-3.157.75-4.05.53l.72-2.9c.896.23 3.757.67 3.33 2.37zm.41-4.24c-.37 1.49-2.662.735-3.405.55l.654-2.64c.744.18 3.137.52 2.75 2.084v.006z"
    />
  </svg>
);

const EthereumIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-blue-100 text-blue-800 p-1">
    <path
      fill="currentColor"
      d="M11.944 17.97L4.58 13.62 11.943 24l7.37-10.38-7.372 4.35h.003zM12.056 0L4.69 12.223l7.365 4.354 7.365-4.35L12.056 0z"
    />
  </svg>
);

const BinanceCoinIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-yellow-100 text-yellow-800 p-1">
    <path
      fill="currentColor"
      d="M12 0L5.6 6.4 8.48 9.28 12 5.76 15.52 9.28 18.4 6.4 12 0ZM5.6 12L2.72 9.12 0 11.84 2.88 14.72 5.6 12ZM8.48 14.72L5.6 17.6 12 24 18.4 17.6 15.52 14.72 12 18.24 8.48 14.72ZM21.12 14.72L24 11.84 21.28 9.12 18.4 12 21.12 14.72ZM12 9.6L9.2 12.4 12 15.2 14.8 12.4 12 9.6Z"
    />
  </svg>
);

const SolanaIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-purple-100 text-purple-800 p-1">
    <path
      fill="currentColor"
      d="M17.2,10.1L19.1,8.2L19.1,8.2L14.2,3.3L12.3,5.2L17.2,10.1ZM16.3,11L11.4,6.1L4.2,13.3L9.1,18.2L16.3,11ZM10,19.1L14.9,24.0L22.1,16.8L17.2,11.9L10,19.1ZM16.8,7.6L13.6,4.4L11.8,6.2L15.0,9.4L16.8,7.6ZM16,11.9L12.8,8.7L4.8,16.7L8.0,19.9L16,11.9ZM10.4,20.5L13.6,23.7L21.6,15.7L18.4,12.5L10.4,20.5Z"
    />
  </svg>
);

const XrpIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-blue-100 text-blue-600 p-1">
    <path
      fill="currentColor"
      d="M19.35,6.04C17.22,2.15 12.94,0 8.66,1.16C6.38,1.8 4.22,3.22 2.82,5.18C2.24,6.04 1.86,6.95 2.57,7.84C2.8,8.2 3.3,8.5 3.74,8.44C4.23,8.36 4.61,7.96 4.96,7.58C6.02,6.4 7.34,5.47 8.83,4.95C12.24,3.8 15.5,4.95 17.98,7.32C18.45,7.79 18.9,8.31 19.48,8.7C20.07,9.05 20.93,8.93 21.4,8.35C21.85,7.77 21.89,6.94 21.52,6.32C21.25,6.01 20.91,5.76 20.55,5.52C20.16,5.25 19.76,5.05 19.35,6.04ZM4.76,15.69C6.87,19.42 10.99,21.52 15.14,20.56C17.5,20.04 19.77,18.57 21.25,16.57C21.86,15.63 22.16,14.67 21.4,13.77C21.13,13.37 20.59,13.03 20.11,13.09C19.67,13.17 19.27,13.53 18.93,13.93C17.9,15.08 16.63,16 15.14,16.54C11.77,17.74 8.47,16.67 5.92,14.35C5.47,13.93 5.03,13.46 4.46,13.06C3.81,12.63 2.95,12.74 2.48,13.34C2.03,13.93 1.97,14.79 2.36,15.4C2.61,15.73 2.97,15.98 3.33,16.23C3.76,16.5 4.26,16.71 4.76,15.69Z"
    />
  </svg>
);

const CardanoIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-blue-100 text-blue-900 p-1">
    <path
      fill="currentColor"
      d="M12,0C5.37,0,0,5.37,0,12s5.37,12,12,12s12-5.37,12-12S18.63,0,12,0z M9.53,15.92c-1.5,0-2.71-1.22-2.71-2.71
      c0-1.5,1.22-2.71,2.71-2.71s2.71,1.22,2.71,2.71C12.24,14.7,11.02,15.92,9.53,15.92z M11.34,7.77c0,1.01-0.82,1.83-1.83,1.83
      s-1.83-0.82-1.83-1.83s0.82-1.83,1.83-1.83S11.34,6.76,11.34,7.77z M14.77,18.63c-0.92,0-1.67-0.75-1.67-1.67
      c0-0.92,0.75-1.67,1.67-1.67c0.92,0,1.67,0.75,1.67,1.67C16.44,17.88,15.69,18.63,14.77,18.63z M14.13,9.09
      c0,1.72-1.4,3.12-3.12,3.12s-3.12-1.4-3.12-3.12s1.4-3.12,3.12-3.12S14.13,7.36,14.13,9.09z M16.69,15.92c-1.5,0-2.71-1.22-2.71-2.71
      c0-1.5,1.22-2.71,2.71-2.71s2.71,1.22,2.71,2.71C19.4,14.7,18.19,15.92,16.69,15.92z M17.46,9.6c-1.01,0-1.83-0.82-1.83-1.83
      s0.82-1.83,1.83-1.83s1.83,0.82,1.83,1.83S18.47,9.6,17.46,9.6z"
    />
  </svg>
);

const DogeIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-yellow-100 text-yellow-700 p-1">
    <path
      fill="currentColor"
      d="M12,0C5.37,0,0,5.37,0,12s5.37,12,12,12s12-5.37,12-12S18.63,0,12,0z M14.3,17.7H9.8v-3.7H7.6v-3.8h2.2V6.3h4.5
      c1.44,0,2.65,0.47,3.55,1.4c0.9,0.93,1.35,2.1,1.35,3.5c0,1.4-0.45,2.57-1.35,3.5C16.94,15.63,15.74,16.1,14.3,16.1h-1.6v1.6
      C12.7,17.7,14.3,17.7,14.3,17.7z M12.7,12.3h1.6c0.53,0,0.97-0.17,1.3-0.5c0.33-0.33,0.5-0.77,0.5-1.3s-0.17-0.97-0.5-1.3
      c-0.33-0.33-0.77-0.5-1.3-0.5h-1.6V12.3z"
    />
  </svg>
);

const USDIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-green-100 text-green-800 font-bold text-sm">
    $
  </div>
);

const EURIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-blue-100 text-blue-800 font-bold text-sm">
    €
  </div>
);

const GBPIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-purple-100 text-purple-800 font-bold text-sm">
    £
  </div>
);

const JPYIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-red-100 text-red-800 font-bold text-sm">
    ¥
  </div>
);

const CADIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-red-50 text-red-700 font-bold text-sm">
    C$
  </div>
);

const AUDIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-yellow-50 text-yellow-700 font-bold text-sm">
    A$
  </div>
);

const CHFIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-red-50 text-red-700 font-bold text-sm">
    Fr
  </div>
);

const CNYIcon = () => (
  <div className="h-8 w-8 flex items-center justify-center rounded-full bg-red-50 text-red-700 font-bold text-sm">
    ¥
  </div>
);

const TetherIcon = () => (
  <svg viewBox="0 0 24 24" width="24" height="24" className="h-8 w-8 rounded-full bg-green-50 text-green-700 p-1">
    <path
      fill="currentColor"
      d="M12,0C5.37,0,0,5.37,0,12s5.37,12,12,12s12-5.37,12-12S18.63,0,12,0z M13.31,14.24
      c-0.59,0.05-3.95,0.34-4.65-0.31c-0.31-0.29-0.47-0.69-0.5-1.17c-0.04-0.64,0.28-1.19,0.73-1.47c0.42-0.26,0.99-0.34,1.62-0.38
      c0.13-0.01,0.26-0.01,0.38-0.01c0.02,0,1.19,0,2.32-0.01c0.11,0,0.21,0,0.31,0c0.72,0,1.29-0.53,1.29-1.19
      c0-0.65-0.57-1.19-1.29-1.19c-0.09,0-5.95,0-5.95,0c-0.05,0-0.09-0.04-0.09-0.09V7.06c0-0.05,0.04-0.09,0.09-0.09h5.95
      c1.6,0,2.89,1.21,2.89,2.7c0,1.37-1.05,2.51-2.45,2.69v0.01c0,0-0.03,0-0.09,0c-0.02,0-0.04,0-0.06,0
      c-0.29,0.01-1.65,0.01-2.38,0.01c-0.14,0-0.28,0-0.42,0.01c-0.28,0.01-0.55,0.03-0.79,0.08c-0.26,0.05-0.5,0.14-0.66,0.31
      c-0.12,0.12-0.19,0.31-0.19,0.52c0,0.06,0.01,0.12,0.02,0.19c0.05,0.23,0.21,0.43,0.52,0.51c0.4,0.1,1.09,0.1,1.67,0.08
      c0.12,0,0.23-0.01,0.34-0.01h4.18c0.05,0,0.09,0.04,0.09,0.09v1.36c0,0.05-0.04,0.09-0.09,0.09h-4.18
      C13.7,14.21,13.5,14.23,13.31,14.24z"
    />
  </svg>
);

export const CurrencyIcons: Record<string, React.ReactNode> = {
  BTC: <BitcoinIcon />,
  ETH: <EthereumIcon />,
  BNB: <BinanceCoinIcon />,
  SOL: <SolanaIcon />,
  XRP: <XrpIcon />,
  ADA: <CardanoIcon />,
  DOGE: <DogeIcon />,
  USDT: <TetherIcon />,
  USD: <USDIcon />,
  EUR: <EURIcon />,
  GBP: <GBPIcon />,
  JPY: <JPYIcon />,
  CAD: <CADIcon />,
  AUD: <AUDIcon />,
  CHF: <CHFIcon />,
  CNY: <CNYIcon />,
};
