import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format a number as currency
 */
export function formatCurrency(
  value: number,
  decimalPlaces: number = 2,
  symbol: string = "$"
): string {
  if (value === null || value === undefined) return "-";

  const formatter = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: decimalPlaces,
    maximumFractionDigits: decimalPlaces,
  });

  // For large numbers, use K, M, B suffixes
  if (value >= 1_000_000_000) {
    return `${symbol}${formatter.format(value / 1_000_000_000)}B`;
  } else if (value >= 1_000_000) {
    return `${symbol}${formatter.format(value / 1_000_000)}M`;
  } else if (value >= 1_000) {
    return `${symbol}${formatter.format(value / 1_000)}K`;
  }

  return `${symbol}${formatter.format(value)}`;
}

/**
 * Format a number as a percentage
 */
export function formatPercentage(value: number): string {
  if (value === null || value === undefined) return "-";

  const formatter = new Intl.NumberFormat("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
    style: "percent",
    signDisplay: "exceptZero",
  });

  return formatter.format(value / 100);
}

/**
 * Format a date
 */
export function formatDate(date: Date | string, format: string = "full"): string {
  const d = typeof date === "string" ? new Date(date) : date;

  switch (format) {
    case "time":
      return d.toLocaleTimeString();
    case "date":
      return d.toLocaleDateString();
    case "datetime":
      return d.toLocaleString();
    case "full":
    default:
      return d.toLocaleString("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "numeric",
        minute: "numeric",
      });
  }
}
