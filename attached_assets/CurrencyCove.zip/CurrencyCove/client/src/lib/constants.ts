import { CurrencyOption } from "@/types";

export const FOREX_CURRENCIES: CurrencyOption[] = [
  { code: "USD", name: "US Dollar" },
  { code: "EUR", name: "Euro" },
  { code: "GBP", name: "British Pound" },
  { code: "JPY", name: "Japanese Yen" },
  { code: "CAD", name: "Canadian Dollar" },
  { code: "AUD", name: "Australian Dollar" },
  { code: "CHF", name: "Swiss Franc" },
  { code: "CNY", name: "Chinese Yuan" },
  { code: "HKD", name: "Hong Kong Dollar" },
  { code: "SGD", name: "Singapore Dollar" },
  { code: "MDL", name: "Moldovan Leu" },
  { code: "AED", name: "UAE Dirham" },
  { code: "PLN", name: "Polish Złoty" },
  { code: "NOK", name: "Norwegian Krone" },
  { code: "SEK", name: "Swedish Krona" },
  { code: "NZD", name: "New Zealand Dollar" },
];

export const CRYPTO_CURRENCIES: CurrencyOption[] = [
  { code: "BTC", name: "Bitcoin" },
  { code: "ETH", name: "Ethereum" },
  { code: "USDT", name: "Tether" },
  { code: "BNB", name: "Binance Coin" },
  { code: "SOL", name: "Solana" },
  { code: "XRP", name: "XRP" },
  { code: "ADA", name: "Cardano" },
  { code: "DOGE", name: "Dogecoin" },
  { code: "DOT", name: "Polkadot" },
  { code: "MATIC", name: "Polygon" },
];

export const DEFAULT_CHART_RANGES = ["1D", "1W", "1M", "3M", "1Y", "All"];
export const DEFAULT_CHART_SOURCES = ["Coinbase", "CoinMarketCap", "DexScreener"];
