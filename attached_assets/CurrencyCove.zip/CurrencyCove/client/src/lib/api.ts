import { Currency, Exchange, CurrencyType, ChartData } from "@/types";

// API keys from import.meta.env (Vite's way of accessing env variables)
const EXCHANGE_RATE_API_KEY = import.meta.env.VITE_EXCHANGE_RATE_API_KEY;
const COIN_GECKO_API_KEY = import.meta.env.VITE_COIN_GECKO_API_KEY;

// Base URLs
const FOREX_API_BASE_URL = "https://v6.exchangerate-api.com/v6";
const CRYPTO_API_BASE_URL = "https://api.coingecko.com/api/v3";

// Handle API errors
const handleApiError = (error: unknown) => {
  console.error("API Error:", error);
  if (error instanceof Error) {
    return new Error(`API Error: ${error.message}`);
  }
  return new Error("Unknown API Error");
};

// Forex API functions
export const fetchForexRates = async (): Promise<Currency[]> => {
  try {
    const response = await fetch(`${FOREX_API_BASE_URL}/${EXCHANGE_RATE_API_KEY}/latest/USD`);
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    
    const data = await response.json();
    if (data.result !== "success") throw new Error(data.error || "Failed to fetch forex rates");
    
    // Transform to our Currency format
    const forexCurrencies: Currency[] = Object.entries(data.conversion_rates)
      .filter(([code]) => code !== "USD") // Remove USD as it's the base
      .map(([code, rate], index) => {
        // Mock data for the fields we don't get from this API
        // In a real app, we would use another API that provides this data
        const percentChange24h = Math.random() * 2 - 1; // Random value between -1 and 1
        const percentChange7d = Math.random() * 4 - 2; // Random value between -2 and 2
        
        return {
          id: index.toString(),
          name: getCurrencyName(code),
          symbol: code,
          priceUsd: 1 / Number(rate), // Invert to get value in USD
          percentChange24h,
          percentChange7d,
          marketCapUsd: null,
          volumeUsd24h: null,
        };
      })
      .sort((a, b) => b.priceUsd - a.priceUsd) // Sort by price
      .slice(0, 10); // Get top 10

    return forexCurrencies;
  } catch (error) {
    throw handleApiError(error);
  }
};

// Crypto API functions
export const fetchCryptoCurrencies = async (): Promise<Currency[]> => {
  try {
    // Add API key to the request headers if available
    const headers: HeadersInit = {};
    if (COIN_GECKO_API_KEY) {
      headers['x-cg-pro-api-key'] = COIN_GECKO_API_KEY;
    }
    
    // Update the endpoint to use Pro API if available, otherwise use the public endpoint
    const baseUrl = COIN_GECKO_API_KEY ? 'https://pro-api.coingecko.com/api/v3' : CRYPTO_API_BASE_URL;
    const apiUrl = `${baseUrl}/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false&price_change_percentage=24h,7d`;
    
    const response = await fetch(apiUrl, { headers });
    if (!response.ok) {
      console.error(`CoinGecko API error: ${response.status}`);
      // Use backup data when API fails
      return getBackupCryptoCurrencies();
    }
    
    const data = await response.json();
    
    if (!Array.isArray(data)) {
      console.error("Invalid data format received from CoinGecko API");
      return getBackupCryptoCurrencies();
    }
    
    const cryptoCurrencies: Currency[] = data.map((coin: any) => ({
      id: coin.id,
      name: coin.name,
      symbol: coin.symbol.toUpperCase(),
      priceUsd: coin.current_price,
      percentChange24h: coin.price_change_percentage_24h || 0,
      percentChange7d: coin.price_change_percentage_7d_in_currency || 0,
      marketCapUsd: coin.market_cap,
      volumeUsd24h: coin.total_volume,
    }));

    return cryptoCurrencies;
  } catch (error) {
    console.error("Failed to fetch cryptocurrency data:", error);
    // Return backup data when API throws an error
    return getBackupCryptoCurrencies();
  }
};

// Helper function to get backup crypto data when the API fails
const getBackupCryptoCurrencies = (): Currency[] => {
  return [
    {
      id: "bitcoin",
      name: "Bitcoin",
      symbol: "BTC",
      priceUsd: 28000,
      percentChange24h: 1.2,
      percentChange7d: -2.3,
      marketCapUsd: 542000000000,
      volumeUsd24h: 23000000000,
    },
    {
      id: "ethereum",
      name: "Ethereum",
      symbol: "ETH",
      priceUsd: 1800,
      percentChange24h: 0.5,
      percentChange7d: -1.8,
      marketCapUsd: 220000000000,
      volumeUsd24h: 12000000000,
    },
    {
      id: "tether",
      name: "Tether",
      symbol: "USDT",
      priceUsd: 1,
      percentChange24h: 0.01,
      percentChange7d: 0.02,
      marketCapUsd: 83000000000,
      volumeUsd24h: 48000000000,
    },
    {
      id: "binancecoin",
      name: "Binance Coin",
      symbol: "BNB",
      priceUsd: 250,
      percentChange24h: -0.8,
      percentChange7d: -3.2,
      marketCapUsd: 38000000000,
      volumeUsd24h: 1200000000,
    },
    {
      id: "solana",
      name: "Solana",
      symbol: "SOL",
      priceUsd: 92,
      percentChange24h: 2.3,
      percentChange7d: 5.1,
      marketCapUsd: 37000000000,
      volumeUsd24h: 2800000000,
    },
    {
      id: "ripple",
      name: "XRP",
      symbol: "XRP",
      priceUsd: 0.55,
      percentChange24h: -1.2,
      percentChange7d: -4.5,
      marketCapUsd: 29000000000,
      volumeUsd24h: 1100000000,
    },
    {
      id: "cardano",
      name: "Cardano",
      symbol: "ADA",
      priceUsd: 0.48,
      percentChange24h: 0.3,
      percentChange7d: -2.7,
      marketCapUsd: 16000000000,
      volumeUsd24h: 650000000,
    },
    {
      id: "dogecoin",
      name: "Dogecoin",
      symbol: "DOGE",
      priceUsd: 0.13,
      percentChange24h: 1.5,
      percentChange7d: -3.8,
      marketCapUsd: 15000000000,
      volumeUsd24h: 800000000,
    },
    {
      id: "polkadot",
      name: "Polkadot",
      symbol: "DOT",
      priceUsd: 7.2,
      percentChange24h: -0.7,
      percentChange7d: -2.9,
      marketCapUsd: 8000000000,
      volumeUsd24h: 350000000,
    },
    {
      id: "polygon",
      name: "Polygon",
      symbol: "MATIC",
      priceUsd: 0.85,
      percentChange24h: 0.9,
      percentChange7d: -1.8,
      marketCapUsd: 7000000000,
      volumeUsd24h: 320000000,
    }
  ];
};

// Fetch all currencies
export const fetchAllCurrencies = async (type?: CurrencyType): Promise<Currency[]> => {
  try {
    if (type === "forex") {
      return fetchForexRates();
    } else if (type === "crypto") {
      return fetchCryptoCurrencies();
    } else {
      // Fetch both types
      const [forexData, cryptoData] = await Promise.all([
        fetchForexRates(),
        fetchCryptoCurrencies(),
      ]);
      return [...forexData, ...cryptoData];
    }
  } catch (error) {
    throw handleApiError(error);
  }
};

// Currency conversion
export const convertCurrency = async (
  fromCurrency: string,
  toCurrency: string,
  amount: number
): Promise<{ convertedAmount: number; rate: number; timestamp: number }> => {
  try {
    // Use the Exchange Rate API for conversion
    if (EXCHANGE_RATE_API_KEY) {
      try {
        // For currency pairs, use the pair conversion endpoint
        const apiUrl = `${FOREX_API_BASE_URL}/${EXCHANGE_RATE_API_KEY}/pair/${fromCurrency}/${toCurrency}/${amount}`;
        const response = await fetch(apiUrl);
        
        if (response.ok) {
          const data = await response.json();
          if (data.result === "success") {
            return {
              convertedAmount: data.conversion_result,
              rate: data.conversion_rate,
              timestamp: data.time_last_update_unix,
            };
          }
        }
      } catch (apiError) {
        console.error("Error with Exchange Rate API:", apiError);
      }
    }
    
    // Try CoinGecko for crypto conversion as a backup
    if (COIN_GECKO_API_KEY && (isCrypto(fromCurrency) || isCrypto(toCurrency))) {
      try {
        const headers: HeadersInit = { 'x-cg-pro-api-key': COIN_GECKO_API_KEY };
        
        // Get price in USD for both currencies
        const baseUrl = 'https://pro-api.coingecko.com/api/v3';
        const fromId = getCoinGeckoId(fromCurrency);
        const toId = getCoinGeckoId(toCurrency);
        
        if (fromId && toId) {
          // If both are crypto, get both prices and calculate
          const apiUrl = `${baseUrl}/simple/price?ids=${fromId},${toId}&vs_currencies=usd`;
          const response = await fetch(apiUrl, { headers });
          
          if (response.ok) {
            const data = await response.json();
            if (data[fromId] && data[toId]) {
              const fromUsdRate = data[fromId].usd;
              const toUsdRate = data[toId].usd;
              const rate = fromUsdRate / toUsdRate;
              
              return {
                convertedAmount: amount * rate,
                rate,
                timestamp: Math.floor(Date.now() / 1000),
              };
            }
          }
        } else if (fromId) {
          // If from is crypto, convert to USD then to destination
          const apiUrl = `${baseUrl}/simple/price?ids=${fromId}&vs_currencies=usd`;
          const response = await fetch(apiUrl, { headers });
          
          if (response.ok) {
            const data = await response.json();
            if (data[fromId]) {
              const fromUsdValue = data[fromId].usd * amount;
              // Now convert USD to target currency
              // Use exchange rate API for this
              const secondApiUrl = `${FOREX_API_BASE_URL}/${EXCHANGE_RATE_API_KEY}/pair/USD/${toCurrency}/1`;
              const secondResponse = await fetch(secondApiUrl);
              
              if (secondResponse.ok) {
                const secondData = await secondResponse.json();
                if (secondData.result === "success") {
                  return {
                    convertedAmount: fromUsdValue * secondData.conversion_rate,
                    rate: data[fromId].usd * secondData.conversion_rate,
                    timestamp: Math.floor(Date.now() / 1000),
                  };
                }
              }
            }
          }
        } else if (toId) {
          // If to is crypto, convert from source to USD then to crypto
          const firstApiUrl = `${FOREX_API_BASE_URL}/${EXCHANGE_RATE_API_KEY}/pair/${fromCurrency}/USD/1`;
          const firstResponse = await fetch(firstApiUrl);
          
          if (firstResponse.ok) {
            const firstData = await firstResponse.json();
            if (firstData.result === "success") {
              const usdValue = amount * firstData.conversion_rate;
              
              // Now convert USD to target crypto
              const apiUrl = `${baseUrl}/simple/price?ids=${toId}&vs_currencies=usd`;
              const response = await fetch(apiUrl, { headers });
              
              if (response.ok) {
                const data = await response.json();
                if (data[toId]) {
                  const toUsdRate = data[toId].usd;
                  return {
                    convertedAmount: usdValue / toUsdRate,
                    rate: firstData.conversion_rate / toUsdRate,
                    timestamp: Math.floor(Date.now() / 1000),
                  };
                }
              }
            }
          }
        }
      } catch (coinGeckoError) {
        console.error("Error with CoinGecko API:", coinGeckoError);
      }
    }
    
    // If all API attempts fail, use estimated rates
    console.log("Using estimated rates for conversion");
    
    // For clarity, we'll use more realistic market rates as our fallback
    const rates: Record<string, Record<string, number>> = {
      "USD": { "EUR": 0.91, "GBP": 0.79, "JPY": 151.12, "BTC": 0.000037, "ETH": 0.00055 },
      "EUR": { "USD": 1.10, "GBP": 0.86, "JPY": 165.34, "BTC": 0.000041, "ETH": 0.00060 },
      "GBP": { "USD": 1.27, "EUR": 1.16, "JPY": 190.22, "BTC": 0.000047, "ETH": 0.00069 },
      "BTC": { "USD": 27000, "EUR": 24570, "GBP": 21330, "ETH": 14.78 },
      "ETH": { "USD": 1820, "EUR": 1656, "GBP": 1441, "BTC": 0.067 }
    };
    
    let rate = 1.0;
    
    if (rates[fromCurrency] && rates[fromCurrency][toCurrency]) {
      rate = rates[fromCurrency][toCurrency];
    } else if (rates[toCurrency] && rates[toCurrency][fromCurrency]) {
      rate = 1 / rates[toCurrency][fromCurrency];
    }
    
    return {
      convertedAmount: amount * rate,
      rate,
      timestamp: Math.floor(Date.now() / 1000),
    };
  } catch (error) {
    throw handleApiError(error);
  }
};

// Helper function to check if a currency is a cryptocurrency
const isCrypto = (currency: string): boolean => {
  const cryptoCurrencies = ['BTC', 'ETH', 'USDT', 'BNB', 'SOL', 'XRP', 'ADA', 'DOGE'];
  return cryptoCurrencies.includes(currency);
};

// Helper function to get CoinGecko ID for a cryptocurrency
const getCoinGeckoId = (currency: string): string | null => {
  const currencyMap: Record<string, string> = {
    'BTC': 'bitcoin',
    'ETH': 'ethereum',
    'USDT': 'tether',
    'BNB': 'binancecoin',
    'SOL': 'solana',
    'XRP': 'ripple',
    'ADA': 'cardano',
    'DOGE': 'dogecoin'
  };
  
  return currencyMap[currency] || null;
};

// Fetch chart data
export const fetchChartData = async (
  currencySymbol: string,
  timeRange: string
): Promise<ChartData[]> => {
  try {
    // Try to get real data from CoinGecko if it's a cryptocurrency
    if (COIN_GECKO_API_KEY && isCrypto(currencySymbol)) {
      try {
        const headers: HeadersInit = { 'x-cg-pro-api-key': COIN_GECKO_API_KEY };
        const coinId = getCoinGeckoId(currencySymbol);
        
        if (coinId) {
          // Define the period and interval based on the time range
          let days = '1';
          switch (timeRange) {
            case "1D":
              days = '1';
              break;
            case "1W":
              days = '7';
              break;
            case "1M":
              days = '30';
              break;
            case "3M":
              days = '90';
              break;
            case "1Y":
              days = '365';
              break;
            case "All":
              days = 'max';
              break;
          }
          
          // Get market chart data from CoinGecko
          const baseUrl = 'https://pro-api.coingecko.com/api/v3';
          const apiUrl = `${baseUrl}/coins/${coinId}/market_chart?vs_currency=usd&days=${days}`;
          
          const response = await fetch(apiUrl, { headers });
          
          if (response.ok) {
            const data = await response.json();
            
            if (data && data.prices && Array.isArray(data.prices)) {
              // Transform the data to our expected format
              return data.prices.map((item: [number, number]) => ({
                time: new Date(item[0]).toISOString(),
                price: item[1],
              }));
            }
          }
        }
      } catch (coinGeckoError) {
        console.error("Error fetching chart data from CoinGecko:", coinGeckoError);
      }
    }
    
    // For forex currencies, try Exchange Rate API historical data if available
    if (EXCHANGE_RATE_API_KEY && !isCrypto(currencySymbol)) {
      try {
        // We would need a historical API endpoint, which Exchange Rate API offers
        // But for simplicity, we'll just use daily recent rates
        const apiUrl = `${FOREX_API_BASE_URL}/${EXCHANGE_RATE_API_KEY}/timeseries/USD/${currencySymbol}`;
        
        // This would require a paid plan for most API providers
        // We'll continue with our fallback data for now
      } catch (forexError) {
        console.error("Error fetching forex chart data:", forexError);
      }
    }
    
    // Fallback to generated data if API calls fail or aren't available
    console.log("Using generated chart data for", currencySymbol);
    
    const now = new Date();
    const data: ChartData[] = [];
    
    let points = 24;
    let interval = 60 * 60 * 1000; // 1 hour in milliseconds
    
    switch (timeRange) {
      case "1W":
        points = 7;
        interval = 24 * 60 * 60 * 1000; // 1 day
        break;
      case "1M":
        points = 30;
        interval = 24 * 60 * 60 * 1000; // 1 day
        break;
      case "3M":
        points = 90;
        interval = 24 * 60 * 60 * 1000; // 1 day
        break;
      case "1Y":
        points = 12;
        interval = 30 * 24 * 60 * 60 * 1000; // 1 month
        break;
      case "All":
        points = 60;
        interval = 30 * 24 * 60 * 60 * 1000; // 1 month
        break;
    }
    
    // Base price on currency type
    let basePrice = 1.0;
    
    if (currencySymbol === "BTC") basePrice = 28000;
    else if (currencySymbol === "ETH") basePrice = 1800;
    else if (currencySymbol === "BNB") basePrice = 250;
    else if (currencySymbol === "SOL") basePrice = 92;
    else if (currencySymbol === "XRP") basePrice = 0.55;
    else if (currencySymbol === "ADA") basePrice = 0.48;
    else if (currencySymbol === "DOGE") basePrice = 0.13;
    
    // For forex, use relatively stable values
    else if (currencySymbol === "EUR") basePrice = 1.09;
    else if (currencySymbol === "GBP") basePrice = 1.27;
    else if (currencySymbol === "JPY") basePrice = 0.0066;
    else if (currencySymbol === "CAD") basePrice = 0.74;
    else if (currencySymbol === "AUD") basePrice = 0.67;
    else if (currencySymbol === "CHF") basePrice = 1.13;
    
    let lastPrice = basePrice;
    
    // Generate more realistic price movements based on currency type
    const volatility = isCrypto(currencySymbol) ? 0.03 : 0.002; // Higher volatility for crypto
    
    for (let i = points; i >= 0; i--) {
      const time = new Date(now.getTime() - i * interval);
      // Create more realistic movements
      const change = (Math.random() * 2 - 1) * volatility; // Random between -volatility and +volatility
      lastPrice = lastPrice * (1 + change);
      
      data.push({
        time: time.toISOString(),
        price: lastPrice,
      });
    }

    return data;
  } catch (error) {
    throw handleApiError(error);
  }
};

// Fetch exchanges
export const fetchExchanges = async (): Promise<Exchange[]> => {
  try {
    // In a real app, we would fetch this from CoinGecko or another API
    // For now, returning mock data
    return [
      {
        id: "1",
        name: "Binance",
        logo: "binance.png",
        url: "https://www.binance.com",
        country: "Global",
        regulated: true,
        volume24h: 13200000000,
        markets: 350,
        trustScore: 4.8,
        fiatSupport: "USD, EUR, GBP, AUD",
        tradingFees: "0.1% - 0.02%",
        btcPrice: 24310.88,
        ethPrice: 1843.66,
      },
      {
        id: "2",
        name: "Coinbase",
        logo: "coinbase.png",
        url: "https://www.coinbase.com",
        country: "United States",
        regulated: true,
        volume24h: 3800000000,
        markets: 150,
        trustScore: 4.5,
        fiatSupport: "USD, EUR, GBP",
        tradingFees: "0.6% - 0.1%",
        btcPrice: 24328.40,
        ethPrice: 1845.22,
      },
      {
        id: "3",
        name: "Kraken",
        logo: "kraken.png",
        url: "https://www.kraken.com",
        country: "United States",
        regulated: true,
        volume24h: 2100000000,
        markets: 130,
        trustScore: 4.7,
        fiatSupport: "USD, EUR, GBP, CAD",
        tradingFees: "0.26% - 0.1%",
        btcPrice: 24315.75,
        ethPrice: 1844.18,
      },
      {
        id: "4",
        name: "KuCoin",
        logo: "kucoin.png",
        url: "https://www.kucoin.com",
        country: "Seychelles",
        regulated: true,
        volume24h: 1800000000,
        markets: 200,
        trustScore: 4.3,
        fiatSupport: "USD, EUR",
        tradingFees: "0.1% - 0.05%",
        btcPrice: 24318.90,
        ethPrice: 1842.55,
      },
      {
        id: "5",
        name: "Bitfinex",
        logo: "bitfinex.png",
        url: "https://www.bitfinex.com",
        country: "Hong Kong",
        regulated: true,
        volume24h: 1500000000,
        markets: 120,
        trustScore: 4.2,
        fiatSupport: "USD, EUR, JPY",
        tradingFees: "0.2% - 0.1%",
        btcPrice: 24320.15,
        ethPrice: 1843.10,
      },
    ];
  } catch (error) {
    throw handleApiError(error);
  }
};

// Helper function to get currency name from code
const getCurrencyName = (code: string): string => {
  const currencyNames: Record<string, string> = {
    USD: "US Dollar",
    EUR: "Euro",
    GBP: "British Pound",
    JPY: "Japanese Yen",
    CAD: "Canadian Dollar",
    AUD: "Australian Dollar",
    CHF: "Swiss Franc",
    CNY: "Chinese Yuan",
    HKD: "Hong Kong Dollar",
    NZD: "New Zealand Dollar",
    SEK: "Swedish Krona",
    NOK: "Norwegian Krone",
    SGD: "Singapore Dollar",
    INR: "Indian Rupee",
    BRL: "Brazilian Real",
    ZAR: "South African Rand",
    RUB: "Russian Ruble",
    MXN: "Mexican Peso",
    IDR: "Indonesian Rupiah",
    KRW: "South Korean Won",
    TRY: "Turkish Lira",
    THB: "Thai Baht",
    PLN: "Polish Złoty",
  };
  
  return currencyNames[code] || code;
};
