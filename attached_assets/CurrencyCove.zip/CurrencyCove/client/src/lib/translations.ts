type Language = "en" | "ro" | "ru";

type TranslationKey = 
  | "dashboard"
  | "forex"
  | "crypto"
  | "exchanges"
  | "converter"
  | "allCurrencies"
  | "searchCurrencies"
  | "price"
  | "marketCap"
  | "volume"
  | "change24h"
  | "change7d"
  | "viewChart"
  | "convert"
  | "sortBy"
  | "cryptoHighlights"
  | "forexHighlights"
  | "quickCurrencyConverter"
  | "marketTrends"
  | "from"
  | "to"
  | "rate"
  | "fee"
  | "delivery"
  | "lastUpdated"
  | "popularConversions"
  | "convertNow"
  | "exchangeDetails"
  | "cryptoMarkets"
  | "forexMarkets"
  | "topCryptoExchanges"
  | "trustScore"
  | "tradingVolume"
  | "markets"
  | "fiatSupport"
  | "tradingFees"
  | "visitExchange"
  | "exchangeComparison"
  | "action"
  | "trade"
  | "realTimeData"
  | "easyConversion"
  | "comprehensiveCharts"
  | "startTrading"
  | "getStarted"
  | "viewAll"
  | "loadingChartData"
  | "errorLoadingChartData"
  | "source"
  | "loadingCurrencies"
  | "noCurrenciesFound"
  | "errorLoadingData"
  | "previous"
  | "next"
  | "showing"
  | "of"
  | "results"
  | "language"
  | "poweredBy"
  | "attribution"
  | "topCryptoCurrencies"
  | "majorForexPairs"
  | "welcomeTo"
  | "tagline"
  | "featuredExchanges";

type TranslationsType = {
  [key in Language]: {
    [k in TranslationKey]: string;
  };
};

export const translations: TranslationsType = {
  en: {
    dashboard: "Dashboard",
    forex: "Forex",
    crypto: "Crypto",
    exchanges: "Exchanges",
    converter: "Converter",
    allCurrencies: "All Currencies",
    searchCurrencies: "Search currencies...",
    price: "Price",
    marketCap: "Market Cap",
    volume: "Volume",
    change24h: "24h Change",
    change7d: "7d Change",
    viewChart: "View Chart",
    convert: "Convert",
    sortBy: "Sort By",
    cryptoHighlights: "Crypto Highlights",
    forexHighlights: "Forex Highlights",
    quickCurrencyConverter: "Quick Currency Converter",
    marketTrends: "Market Trends",
    from: "From",
    to: "To",
    rate: "Rate",
    fee: "Fee",
    delivery: "Delivery",
    lastUpdated: "Last updated",
    popularConversions: "Popular Conversions",
    convertNow: "Convert Now",
    exchangeDetails: "Exchange Details",
    cryptoMarkets: "Cryptocurrency Markets",
    forexMarkets: "Forex Markets",
    topCryptoExchanges: "Top Cryptocurrency Exchanges",
    trustScore: "Trust Score",
    tradingVolume: "Trading Volume (24h)",
    markets: "Markets",
    fiatSupport: "Fiat Support",
    tradingFees: "Trading Fees",
    visitExchange: "Visit Exchange",
    exchangeComparison: "Exchange Comparison",
    action: "Action",
    trade: "Trade",
    realTimeData: "Real-Time Data",
    easyConversion: "Easy Conversion",
    comprehensiveCharts: "Comprehensive Charts",
    startTrading: "Start Trading Today",
    getStarted: "Get Started",
    viewAll: "View All",
    loadingChartData: "Loading chart data...",
    errorLoadingChartData: "Error loading chart data. Please try again.",
    source: "Source",
    loadingCurrencies: "Loading...",
    noCurrenciesFound: "No currencies found.",
    errorLoadingData: "Error loading data. Please try again.",
    previous: "Previous",
    next: "Next",
    showing: "Showing",
    of: "of",
    results: "results",
    language: "Language",
    poweredBy: "Powered by",
    attribution: "Cryptocurrency data provided by CoinGecko",
    topCryptoCurrencies: "Top Cryptocurrencies",
    majorForexPairs: "Major Forex Pairs",
    welcomeTo: "Welcome to ExchangeHub",
    tagline: "Your one-stop platform for currency exchange",
    featuredExchanges: "Featured Exchanges"
  },
  ro: {
    dashboard: "Tablou de bord",
    forex: "Forex",
    crypto: "Cripto",
    exchanges: "Schimburi",
    converter: "Convertor",
    allCurrencies: "Toate monedele",
    searchCurrencies: "Caută monede...",
    price: "Preț",
    marketCap: "Capitalizare de piață",
    volume: "Volum",
    change24h: "Schimbare 24h",
    change7d: "Schimbare 7z",
    viewChart: "Vezi grafic",
    convert: "Convertește",
    sortBy: "Sortează după",
    cryptoHighlights: "Cripto evidențiate",
    forexHighlights: "Forex evidențiate",
    quickCurrencyConverter: "Convertor rapid de valută",
    marketTrends: "Tendințe de piață",
    from: "De la",
    to: "La",
    rate: "Rată",
    fee: "Taxă",
    delivery: "Livrare",
    lastUpdated: "Ultima actualizare",
    popularConversions: "Conversii populare",
    convertNow: "Convertește acum",
    exchangeDetails: "Detalii schimb",
    cryptoMarkets: "Piețe criptomonede",
    forexMarkets: "Piețe Forex",
    topCryptoExchanges: "Top schimburi de criptomonede",
    trustScore: "Scor de încredere",
    tradingVolume: "Volum de tranzacționare (24h)",
    markets: "Piețe",
    fiatSupport: "Suport fiat",
    tradingFees: "Taxe de tranzacționare",
    visitExchange: "Vizitează schimbul",
    exchangeComparison: "Comparație schimburi",
    action: "Acțiune",
    trade: "Tranzacționează",
    realTimeData: "Date în timp real",
    easyConversion: "Conversie ușoară",
    comprehensiveCharts: "Grafice comprehensive",
    startTrading: "Începe tranzacționarea astăzi",
    getStarted: "Începe",
    viewAll: "Vezi toate",
    loadingChartData: "Se încarcă datele graficului...",
    errorLoadingChartData: "Eroare la încărcarea datelor. Încercați din nou.",
    source: "Sursă",
    loadingCurrencies: "Se încarcă...",
    noCurrenciesFound: "Nu s-au găsit monede.",
    errorLoadingData: "Eroare la încărcarea datelor. Încercați din nou.",
    previous: "Anterior",
    next: "Următor",
    showing: "Se arată",
    of: "din",
    results: "rezultate",
    language: "Limbă",
    poweredBy: "Alimentat de",
    attribution: "Date criptomonede furnizate de CoinGecko",
    topCryptoCurrencies: "Top Criptomonede",
    majorForexPairs: "Perechi Forex Majore",
    welcomeTo: "Bine ați venit la ExchangeHub",
    tagline: "Platforma dumneavoastră completă pentru schimb valutar",
    featuredExchanges: "Schimburi recomandate"
  },
  ru: {
    dashboard: "Панель управления",
    forex: "Форекс",
    crypto: "Крипто",
    exchanges: "Биржи",
    converter: "Конвертер",
    allCurrencies: "Все валюты",
    searchCurrencies: "Поиск валют...",
    price: "Цена",
    marketCap: "Рыночная капитализация",
    volume: "Объем",
    change24h: "Изменение за 24ч",
    change7d: "Изменение за 7д",
    viewChart: "Просмотр графика",
    convert: "Конвертировать",
    sortBy: "Сортировать по",
    cryptoHighlights: "Основные криптовалюты",
    forexHighlights: "Основные форекс валюты",
    quickCurrencyConverter: "Быстрый конвертер валют",
    marketTrends: "Рыночные тренды",
    from: "Из",
    to: "В",
    rate: "Курс",
    fee: "Комиссия",
    delivery: "Доставка",
    lastUpdated: "Последнее обновление",
    popularConversions: "Популярные конверсии",
    convertNow: "Конвертировать сейчас",
    exchangeDetails: "Детали биржи",
    cryptoMarkets: "Рынки криптовалют",
    forexMarkets: "Форекс рынки",
    topCryptoExchanges: "Топ криптовалютных бирж",
    trustScore: "Оценка доверия",
    tradingVolume: "Объем торгов (24ч)",
    markets: "Рынки",
    fiatSupport: "Поддержка фиатных валют",
    tradingFees: "Торговые комиссии",
    visitExchange: "Посетить биржу",
    exchangeComparison: "Сравнение бирж",
    action: "Действие",
    trade: "Торговать",
    realTimeData: "Данные в реальном времени",
    easyConversion: "Простая конвертация",
    comprehensiveCharts: "Подробные графики",
    startTrading: "Начните торговать сегодня",
    getStarted: "Начать",
    viewAll: "Смотреть все",
    loadingChartData: "Загрузка данных графика...",
    errorLoadingChartData: "Ошибка загрузки данных. Пожалуйста, попробуйте снова.",
    source: "Источник",
    loadingCurrencies: "Загрузка...",
    noCurrenciesFound: "Валюты не найдены.",
    errorLoadingData: "Ошибка загрузки данных. Пожалуйста, попробуйте снова.",
    previous: "Предыдущий",
    next: "Следующий",
    showing: "Показано",
    of: "из",
    results: "результатов",
    language: "Язык",
    poweredBy: "При поддержке",
    attribution: "Данные криптовалют предоставлены CoinGecko",
    topCryptoCurrencies: "Топ Криптовалют",
    majorForexPairs: "Основные Форекс Пары",
    welcomeTo: "Добро пожаловать в ExchangeHub",
    tagline: "Ваша универсальная платформа для обмена валют",
    featuredExchanges: "Рекомендуемые биржи"
  }
};

export type { Language, TranslationKey };