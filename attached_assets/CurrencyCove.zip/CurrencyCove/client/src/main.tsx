import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

const meta = document.createElement('meta');
meta.name = 'description';
meta.content = 'ExchangeHub - Modern platform for viewing and converting between forex and cryptocurrency with live data and interactive charts';
document.head.appendChild(meta);

const title = document.createElement('title');
title.textContent = 'ExchangeHub - Currency & Crypto Exchange';
document.head.appendChild(title);

createRoot(document.getElementById("root")!).render(<App />);
