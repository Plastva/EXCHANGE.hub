import { useQuery } from "@tanstack/react-query";
import {
  fetchAllCurrencies,
  fetchForexRates,
  fetchCryptoCurrencies,
  convertCurrency,
  fetchChartData,
  fetchExchanges,
} from "@/lib/api";
import { CurrencyType } from "@/types";

// Hook to get forex currencies
export const useForexCurrencies = () => {
  return useQuery({
    queryKey: ["/api/forex"],
    queryFn: () => fetchForexRates(),
  });
};

// Hook to get crypto currencies
export const useCryptoCurrencies = () => {
  return useQuery({
    queryKey: ["/api/crypto"],
    queryFn: () => fetchCryptoCurrencies(),
  });
};

// Hook to get all currencies of a specific type or both
export const useAllCurrencies = (type?: CurrencyType) => {
  return useQuery({
    queryKey: ["/api/currencies", type],
    queryFn: () => fetchAllCurrencies(type),
  });
};

// Hook for currency conversion
export const useCurrencyConversion = (
  fromCurrency: string,
  toCurrency: string,
  amount: number
) => {
  return useQuery({
    queryKey: ["/api/convert", fromCurrency, toCurrency, amount],
    queryFn: () => convertCurrency(fromCurrency, toCurrency, amount),
    enabled: !!fromCurrency && !!toCurrency && amount > 0,
  });
};

// Hook to get chart data for a currency
export const useCurrencyChartData = (
  currencySymbol: string,
  timeRange: string
) => {
  return useQuery({
    queryKey: ["/api/chart", currencySymbol, timeRange],
    queryFn: () => fetchChartData(currencySymbol, timeRange),
    enabled: !!currencySymbol,
  });
};

// Hook to get exchanges
export const useExchanges = () => {
  return useQuery({
    queryKey: ["/api/exchanges"],
    queryFn: () => fetchExchanges(),
  });
};
