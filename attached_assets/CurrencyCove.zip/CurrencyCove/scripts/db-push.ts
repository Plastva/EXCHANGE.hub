import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import ws from "ws";
import * as schema from "../shared/schema";

// Required for Neon serverless
neonConfig.webSocketConstructor = ws;

async function main() {
  console.log("Starting database schema push...");
  
  if (!process.env.DATABASE_URL) {
    console.error("No DATABASE_URL environment variable found. Please set up your database.");
    process.exit(1);
  }
  
  try {
    // Connect to the database
    const pool = new Pool({ connectionString: process.env.DATABASE_URL });
    const db = drizzle(pool, { schema });
    
    // Create tables based on schema
    console.log("Creating tables if they don't exist...");
    
    const tableCreations = [
      `CREATE TABLE IF NOT EXISTS currencies (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        symbol TEXT NOT NULL UNIQUE,
        price_usd NUMERIC(20, 8) NOT NULL,
        percent_change_24h NUMERIC(10, 2),
        percent_change_7d NUMERIC(10, 2),
        market_cap_usd NUMERIC(20, 2),
        volume_usd_24h NUMERIC(20, 2),
        type TEXT NOT NULL,
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )`,
      
      `CREATE TABLE IF NOT EXISTS exchanges (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        logo TEXT,
        url TEXT NOT NULL,
        country TEXT,
        regulated BOOLEAN DEFAULT FALSE,
        volume_24h NUMERIC(20, 2),
        markets INTEGER,
        trust_score NUMERIC(3, 1),
        fiat_support TEXT,
        trading_fees TEXT,
        btc_price NUMERIC(20, 2),
        eth_price NUMERIC(20, 2),
        updated_at TIMESTAMP NOT NULL DEFAULT NOW()
      )`,
      
      `CREATE TABLE IF NOT EXISTS conversion_history (
        id SERIAL PRIMARY KEY,
        from_currency TEXT NOT NULL,
        to_currency TEXT NOT NULL,
        from_amount NUMERIC(20, 8) NOT NULL,
        to_amount NUMERIC(20, 8) NOT NULL,
        rate NUMERIC(20, 8) NOT NULL,
        timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
        ip_address TEXT
      )`
    ];
    
    for (const createTable of tableCreations) {
      try {
        await pool.query(createTable);
        console.log("Table created or already exists.");
      } catch (err) {
        console.error("Error creating table:", err);
      }
    }
    
    console.log("Database schema push completed successfully.");
    
    // Close the connection
    await pool.end();
    
    process.exit(0);
  } catch (error) {
    console.error("Error during database schema push:", error);
    process.exit(1);
  }
}

main();